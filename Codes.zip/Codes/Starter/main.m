%% Dieckmann-Doebeli example: generate the study's short-time initial states
% Starter is a study-specific exact Direct-method trajectory.  It is not a
% required component of the Direct or TDTL algorithms for another model.

clc
clear

scriptDir = fileparts(mfilename('fullpath'));
addpath(scriptDir);

%% 1. Model-specific parameters: Dieckmann-Doebeli example
modelParams.r = 1;                       % intrinsic birth rate
modelParams.K0 = 300;                    % carrying capacity
modelParams.x0 = 0;                      % carrying capacity peak
modelParams.sigmaK = 1;                  % width of carrying capacity function
modelParams.sigmaC = 0.4;                % width of competition kernel
modelParams.traitMin = -0.5;             % minimum trait
modelParams.traitMax = 0.5;              % maximum trait
modelParams.mutaProb = 0.001;            % mutation probability per birth
modelParams.mutaDeviation = 0.05;        % mutation standard deviation

%% 2. Direct-method algorithm settings
% This is an algorithmic memory setting, not a Dieckmann model parameter.
% A full trait buffer grows by 100 slots at once instead of reallocating the
% array after every birth.
algParams.bufferGrowth = 100;            % trait-buffer slots added when full

%% 3. Study-specific Starter protocol
initialPopulation = 500;
initialTrait = -0.3;
totalTime = 10000;
recordInterval = 1;

%% 4. Reproducibility and runtime settings
baseSeed = 20260618;
debugMode = false;
progressEvery = 500;

%% 5. Output path
outputFile = fullfile(scriptDir, 'baseTraits.mat');

% The random-number generator is set once because Starter is one continuous
% trajectory.  The same seed therefore reproduces baseTraits exactly.
rng(baseSeed, 'twister');

% Starter uses a homogeneous point population, so constructing it here is
% clearer than routing this one-line operation through a separate helper.
if initialPopulation < 1 || initialPopulation ~= round(initialPopulation) || ...
        ~isfinite(initialTrait)
    error('Starter:InvalidInitialState', ...
        'Initial population must be a positive integer and trait finite.');
end
initialTraits = repmat(double(initialTrait), 1, double(initialPopulation));
populationSize = numel(initialTraits);
traitBuffer = zeros(1, ...
    populationSize + algParams.bufferGrowth);
traitBuffer(1:populationSize) = initialTraits;
birthRates = zeros(size(traitBuffer));
deathRates = zeros(size(traitBuffer));
[initialBirth, initialDeath] = computeRates( ...
    initialTraits, populationSize, modelParams);
birthRates(1:populationSize) = initialBirth;
deathRates(1:populationSize) = initialDeath;

targetTimes = recordInterval:recordInterval:totalTime;
if isempty(targetTimes) || targetTimes(end) ~= totalTime
    targetTimes(end + 1) = totalTime;
end
baseTraits = cell(1, numel(targetTimes));
recordIndex = 1;
time = 0;

while time < totalTime && populationSize > 0
    totalRate = sum(deathRates(1:populationSize)) + ...
        sum(birthRates(1:populationSize));
    if totalRate == 0
        time = totalTime;
        break
    end
    if ~isfinite(totalRate) || totalRate <= 0
        error('simulateStep:InvalidTotalRate', ...
            'Total event propensity must be finite and positive.');
    end
    waitingTime = -log(max(rand, realmin)) ./ totalRate;
    remainingTime = totalTime - time;
    if waitingTime > remainingTime
        time = totalTime;
        break
    end
    eventTime = min(time + waitingTime, totalTime);
    % Targets before the next event receive the current, pre-event state.
    % Retain the sampled wait so recording does not alter the exact path.
    if recordIndex <= numel(targetTimes) && ...
            targetTimes(recordIndex) < eventTime
        preEventTraits = traitBuffer(1:populationSize);
        while recordIndex <= numel(targetTimes) && ...
                targetTimes(recordIndex) < eventTime
            baseTraits{recordIndex} = preEventTraits;
            if progressEvery > 0 && mod(recordIndex, progressEvery) == 0
                fprintf('Starter recorded %d/%d states.\n', ...
                    recordIndex, numel(baseTraits));
            end
            recordIndex = recordIndex + 1;
        end
    end
    [traitBuffer, populationSize, ~, birthRates, deathRates] = ...
        simulateStep( ...
        populationSize, traitBuffer, birthRates, deathRates, modelParams, ...
        algParams, remainingTime, waitingTime);
    time = eventTime;

    if debugMode
        validateDirectState(traitBuffer, populationSize, modelParams, ...
            birthRates, deathRates);
    end

    % A target exactly at the event receives the updated state.  Event times
    % are not stored because each saved state belongs to its target time.
    while recordIndex <= numel(targetTimes) && ...
            time >= targetTimes(recordIndex)
        baseTraits{recordIndex} = traitBuffer(1:populationSize);
        if progressEvery > 0 && mod(recordIndex, progressEvery) == 0
            fprintf('Starter recorded %d/%d states.\n', ...
                recordIndex, numel(targetTimes));
        end
        recordIndex = recordIndex + 1;
    end
end

% Extinction or a next event after totalTime leaves the state unchanged for
% all remaining targets.  In particular, no beyond-terminal event is saved.
while recordIndex <= numel(targetTimes)
    baseTraits{recordIndex} = traitBuffer(1:populationSize);
    recordIndex = recordIndex + 1;
end

% Only baseTraits is stored so the two short-time programs can load it
% without depending on any other project directory.
save(outputFile, 'baseTraits', '-v7.3');
fprintf('Saved %d starter states to %s\n', numel(baseTraits), outputFile);
