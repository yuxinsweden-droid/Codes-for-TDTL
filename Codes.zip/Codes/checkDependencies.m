function report = checkDependencies()
%CHECKDEPENDENCIES Report MATLAB functions needed by the supplied programs.
%
% OUTPUT
%   report - struct containing release, required-function availability, and
%            optional Parallel Computing Toolbox availability.

report = struct();
report.matlabRelease = string(version('-release'));
report.testedRelease = "R2024a";

requiredFunctions = ["normcdf", "norminv", "normrnd", "poissrnd"];
available = false(size(requiredFunctions));
for idx = 1:numel(requiredFunctions)
    available(idx) = exist(requiredFunctions(idx), 'file') == 2;
end
report.requiredFunctions = table(requiredFunctions(:), available(:), ...
    'VariableNames', {'Function', 'Available'});
report.statisticsToolboxAvailable = all(available);
report.parallelToolboxInstalled = ~isempty(ver('parallel'));
report.parallelLicenseAvailable = license('test', ...
    'Distrib_Computing_Toolbox');

fprintf('MATLAB release: %s (tested: %s)\n', ...
    report.matlabRelease, report.testedRelease);
disp(report.requiredFunctions);
if ~report.statisticsToolboxAvailable
    error('Codes:MissingStatisticsToolbox', ...
        ['Statistics and Machine Learning Toolbox functions are missing. ' ...
        'See DEPENDENCIES.md.']);
end
if report.parallelToolboxInstalled && report.parallelLicenseAvailable
    fprintf('Parallel Computing Toolbox: available.\n');
else
    fprintf(['Parallel Computing Toolbox: unavailable; simulations will ' ...
        'use their serial fallback.\n']);
end
end

