%% Dieckmann-Doebeli example: short-time trait-discretized tau-leaping
% This script reproduces the short-time protocol used in this study.
% Continuous individual traits are retained for W1; the grid is used for
% propensities and reaction channels.

clc
clear

scriptDir = fileparts(mfilename('fullpath'));
addpath(scriptDir);

%% 1. Model-specific parameters: Dieckmann-Doebeli example
modelParams.r = 1;                     % intrinsic birth rate
modelParams.K0 = 300;                  % carrying capacity
modelParams.x0 = 0;                    % carrying capacity peak
modelParams.sigmaK = 1;                % width of carrying capacity function
modelParams.sigmaC = 0.4;              % width of competition kernel
modelParams.traitMin = -0.5;           % minimum trait
modelParams.traitMax = 0.5;            % maximum trait
modelParams.mutaProb = 0.001;          % mutation probability per birth
modelParams.mutaDeviation = 0.05;      % mutation standard deviation

%% 2. TDTL algorithm and discretization settings
algParams.numTraitBins = 19;           % uniform computational trait bins
algParams.mutationCoverageCutoff = 0.99; % retained Gaussian mutation mass
algParams.epsilon = 0.1;               % tau-selection accuracy parameter
algParams.nCritical = 2;               % critical-channel threshold
algParams.leapSwitchFactor = 10;       % require untruncated candidate > 10/a0
algParams.maxDirectSteps = 100;         % fallback events before re-estimation

%% 3. Study-specific short-time protocol
totalTime = 1;
repeatTimes = 100000;
baseTraitsIndices = 500:500:10000;

%% 4. Reproducibility and runtime settings
baseSeed = 20260618;
useParallel = true;
numWorkers = [];       % [] lets MATLAB choose the local-pool size.
debugMode = false;     % true validates traits and counts after every update.

%% 5. Input and output paths
baseTraitsFile = fullfile(scriptDir, 'baseTraits.mat');
outputDir = fullfile(scriptDir, 'Data2');

%% 6. Load the study's 20 initial states
source = load(baseTraitsFile, 'baseTraits');
if ~isfield(source, 'baseTraits') || ...
        numel(source.baseTraits) < max(baseTraitsIndices)
    error('TDTLShort:InvalidBaseTraits', ...
        'baseTraits.mat does not contain indices 500:500:10000.');
end
if ~isfolder(outputDir)
    mkdir(outputDir);
end

% Each repeat owns its seed, so for/parfor scheduling does not change output.
parallelAvailable = ~isempty(ver('parallel')) && ...
    license('test', 'Distrib_Computing_Toolbox');
runInParallel = useParallel && parallelAvailable;
if useParallel && ~parallelAvailable
    warning('TDTLShort:SerialFallback', ...
        'Parallel Computing Toolbox is unavailable; using a serial loop.');
end
if runInParallel
    pool = gcp('nocreate');
    if isempty(pool)
        if isempty(numWorkers)
            parpool('local');
        else
            parpool('local', numWorkers);
        end
    elseif ~isempty(numWorkers) && pool.NumWorkers ~= numWorkers
        error('TDTLShort:PoolSize', ...
            'The existing pool does not match numWorkers.');
    end
end

%% 7. Simulate each initial state
for sampleIndex = 1:numel(baseTraitsIndices)
    outputFile = fullfile(outputDir, ...
        sprintf('sample_%02d.mat', sampleIndex));
    seeds = baseSeed + sampleIndex * 100000 + (1:repeatTimes)';
    if any(seeds > 2^32 - 1)
        error('TDTLShort:SeedRange', ...
            'A requested seed exceeds the Twister seed range.');
    end

    initialTraits = double(source.baseTraits{ ...
        baseTraitsIndices(sampleIndex)}(:).');
    [binEdges, binCenters, initialBinnedTraits, initialCounts] = ...
        initTraitGrid(algParams.numTraitBins, initialTraits, modelParams);
    channels = buildReactionChannels( ...
        binEdges, binCenters, modelParams, algParams);

    exactTraits = cell(repeatTimes, 1);
    binCounts = zeros(repeatTimes, algParams.numTraitBins, 'uint32');
    fprintf('TDTL short sample %d/%d: %d repeats.\n', ...
        sampleIndex, numel(baseTraitsIndices), repeatTimes);

    % tauEstimate uses nCritical independently of the 10/a0 leap switch.
    % Infeasible leaps are halved until feasible or until the Direct fallback
    % is selected.  At most maxDirectSteps exact events are taken before tau
    % is reconsidered.
    if runInParallel
        parfor repeatIndex = 1:repeatTimes
            [exactTraits{repeatIndex}, binCounts(repeatIndex, :)] = ...
                simulateRecordedTDTL(seeds(repeatIndex), totalTime, ...
                modelParams, algParams, binEdges, binCenters, ...
                initialBinnedTraits, initialCounts, channels, debugMode);
        end
    else
        for repeatIndex = 1:repeatTimes
            [exactTraits{repeatIndex}, binCounts(repeatIndex, :)] = ...
                simulateRecordedTDTL(seeds(repeatIndex), totalTime, ...
                modelParams, algParams, binEdges, binCenters, ...
                initialBinnedTraits, initialCounts, channels, debugMode);
        end
    end

    baseTraitsIndex = baseTraitsIndices(sampleIndex); 
    partialFile = [outputFile '.part.mat'];
    save(partialFile, 'exactTraits', 'binCounts', 'binEdges', 'seeds', ...
        'baseTraitsIndex', '-v7.3');
    movefile(partialFile, outputFile, 'f');
end
