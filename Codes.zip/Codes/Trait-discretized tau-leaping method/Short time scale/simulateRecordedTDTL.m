function [exactTraits, binCounts, diagnostics] = simulateRecordedTDTL( ...
        seed, totalTime, modelParams, algParams, binEdges, binCenters, ...
        initialBinnedTraits, initialCounts, channels, debugMode)
%SIMULATERECORDEDTDTL Run one seeded short-time TDTL realization.
%
% The bin counts drive propensity and tau calculations, while binnedTraits
% retains every continuous individual trait for W1.  A leap is used only
% when the untruncated candidate exceeds 10/a0 and tauEstimate returns a
% feasible leap.  Capping that leap at totalTime does not force a switch.
% Otherwise, up to algParams.maxDirectSteps exact reactions are executed
% before tau is estimated again.
%
% Randomness: this function sets the complete repeat-level Twister stream,
% making its result independent of serial or parallel scheduling.

rng(seed, 'twister');
binnedTraits = initialBinnedTraits;
counts = initialCounts;
t = 0;
diagnostics = struct('tauSteps', 0, 'directSteps', 0, ...
    'tauFallbacks', 0);

while t < totalTime
    [~, ~, rates] = computeRates( ...
        counts, binCenters, channels, modelParams);
    if sum(rates) <= 0
        break
    end

    [useTauLeap, tau, firingCounts] = tauEstimate( ...
        rates, channels, counts, algParams, totalTime - t);
    if useTauLeap
        [binnedTraits, counts] = tauStep( ...
            binnedTraits, counts, channels, firingCounts, ...
            binEdges, binCenters, modelParams);
        if tau >= totalTime - t
            t = totalTime;
        else
            t = t + tau;
        end
        diagnostics.tauSteps = diagnostics.tauSteps + 1;
        if debugMode
            validateTraitState(binnedTraits, counts, binEdges);
        end
    else
        diagnostics.tauFallbacks = diagnostics.tauFallbacks + 1;
        for directIndex = 1:algParams.maxDirectSteps
            if t >= totalTime
                break
            end
            [~, ~, rates] = computeRates( ...
                counts, binCenters, channels, modelParams);
            if sum(rates) <= 0
                break
            end
            remainingTime = totalTime - t;
            [binnedTraits, counts, dt, eventOccurred] = directStep( ...
                rates, channels, binnedTraits, counts, ...
                binEdges, binCenters, modelParams, remainingTime);
            if ~isfinite(dt) || dt < 0
                error('TDTLShort:InvalidDirectTime', ...
                    'Direct fallback returned an invalid time step.');
            end
            if dt >= remainingTime
                t = totalTime;
            else
                t = t + dt;
            end
            diagnostics.directSteps = diagnostics.directSteps + eventOccurred;
            if debugMode
                validateTraitState(binnedTraits, counts, binEdges);
            end
        end
    end
end

validateTraitState(binnedTraits, counts, binEdges);
exactTraits = reshape([binnedTraits{:}], 1, []);
binCounts = uint32(counts);
end
