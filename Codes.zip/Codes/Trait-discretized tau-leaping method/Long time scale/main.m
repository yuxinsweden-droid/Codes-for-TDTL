%% Dieckmann-Doebeli example: long-time trait-discretized tau-leaping
% This script reproduces the long-time protocol used in this study.  It uses
% the same model and TDTL core as the short-time program, but records a common
% time grid for time-resolved W1.

clc
clear

scriptDir = fileparts(mfilename('fullpath'));
addpath(scriptDir);

%% 1. Model-specific parameters: Dieckmann-Doebeli example
modelParams.r = 1;                       % intrinsic birth rate
modelParams.K0 = 300;                    % carrying capacity
modelParams.x0 = 0;                      % carrying capacity peak
modelParams.sigmaK = 1;                  % width of carrying capacity function
modelParams.sigmaC = 0.4;                % width of competition kernel
modelParams.traitMin = -0.5;             % minimum trait
modelParams.traitMax = 0.5;              % maximum trait
modelParams.mutaProb = 0.001;            % mutation probability per birth
modelParams.mutaDeviation = 0.05;        % mutation standard deviation

%% 2. TDTL algorithm and discretization settings
algParams.numTraitBins = 19;             % uniform computational trait bins
algParams.mutationCoverageCutoff = 0.99; % retained Gaussian mutation mass
algParams.epsilon = 0.1;                 % tau-selection accuracy parameter
algParams.nCritical = 2;                 % critical-channel threshold
algParams.leapSwitchFactor = 10;         % require untruncated candidate > 10/a0
algParams.maxDirectSteps = 100;           % fallback events before re-estimation

%% 3. Study-specific long-time protocol
initialPopulation = 500;
initialTrait = -0.3;
totalTime = 10000;
recordInterval = 1;
repeatTimes = 400;

%% 4. Reproducibility and runtime settings
baseSeed = 20260618;
useParallel = true;
numWorkers = [];       % [] lets MATLAB choose the local-pool size.
debugMode = false;     % true validates traits and counts after every update.

%% 5. Output path
outputDir = fullfile(scriptDir, 'Data2');
if ~isfolder(outputDir)
    mkdir(outputDir);
end

%% 6. Initial state and shared reaction channels
% Both long methods use this exact grid. Tau candidates are capped at the
% next observation before firing counts are drawn; exact fallback records
% pre-event states at crossed targets. The grid therefore constrains tau.
targetTimes = 0:recordInterval:totalTime;
if targetTimes(end) ~= totalTime
    targetTimes(end + 1) = totalTime;
end
traitDistribution.type = 'point';
traitDistribution.value = initialTrait;
traitDistribution.numIndividuals = initialPopulation;
initialTraits = initPopulation(traitDistribution);

[binEdges, binCenters, initialBinnedTraits, initialCounts] = ...
    initTraitGrid(algParams.numTraitBins, initialTraits, modelParams);
channels = buildReactionChannels( ...
    binEdges, binCenters, modelParams, algParams);

%% 7. Configure serial or parallel execution
parallelAvailable = ~isempty(ver('parallel')) && ...
    license('test', 'Distrib_Computing_Toolbox');
runInParallel = useParallel && parallelAvailable;
if useParallel && ~parallelAvailable
    warning('TDTLLong:SerialFallback', ...
        'Parallel Computing Toolbox is unavailable; using serial execution.');
end
if runInParallel
    pool = gcp('nocreate');
    if isempty(pool)
        if isempty(numWorkers)
            parpool('local');
        else
            parpool('local', numWorkers);
        end
    elseif ~isempty(numWorkers) && pool.NumWorkers ~= numWorkers
        error('TDTLLong:PoolSize', ...
            'The existing pool does not match numWorkers.');
    end
end

%% 8. Run all long-time trajectories
if runInParallel
    parfor repeatIndex = 1:repeatTimes
        seed = baseSeed + repeatIndex;
        outputFile = fullfile(outputDir, ...
            sprintf('repeat_%04d.mat', repeatIndex));
        simulateLongRecordedTDTL(seed, totalTime, targetTimes, ...
            modelParams, algParams, binEdges, binCenters, ...
            initialBinnedTraits, initialCounts, channels, ...
            outputFile, debugMode);
    end
else
    for repeatIndex = 1:repeatTimes
        seed = baseSeed + repeatIndex;
        outputFile = fullfile(outputDir, ...
            sprintf('repeat_%04d.mat', repeatIndex));
        fprintf('TDTL long repeat %d/%d.\n', repeatIndex, repeatTimes);
        simulateLongRecordedTDTL(seed, totalTime, targetTimes, ...
            modelParams, algParams, binEdges, binCenters, ...
            initialBinnedTraits, initialCounts, channels, ...
            outputFile, debugMode);
    end
end
