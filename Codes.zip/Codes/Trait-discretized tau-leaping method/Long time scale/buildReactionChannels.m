function channels = buildReactionChannels( ...
        binEdges, binCenters, modelParams, algParams)
%BUILDREACTIONCHANNELS Define the model-to-TDTL reaction interface.
%
% The returned metadata are shared by propensity calculation, tau selection,
% exact fallback and leap application.  A new reaction model should replace
% this function and preserve the documented fields.
%
% CHANNEL FIELDS
%   stoichiometry       - numBins-by-numChannels count changes.
%   typeCode            - death, within-bin birth, or cross-bin mutation.
%   sourceBin           - source population used by each channel.
%   targetBin           - offspring target; zero for death.
%   mutationProbability - Gaussian mass for each cross-bin channel.
%   withinMutationMass  - Gaussian mass retained inside each source bin.

numBins = numel(binCenters);
if numel(binEdges) ~= numBins + 1 || ...
        algParams.numTraitBins ~= numBins
    error('buildReactionChannels:GridMismatch', ...
        'Bin edges, centers and algParams.numTraitBins disagree.');
end

channels.codes.death = uint8(1);
channels.codes.withinBirth = uint8(2);
channels.codes.crossMutation = uint8(3);

% Death and within-bin birth channels occupy the first two blocks.
channels.stoichiometry = [-eye(numBins), eye(numBins)];
channels.typeCode = [repmat(channels.codes.death, 1, numBins), ...
    repmat(channels.codes.withinBirth, 1, numBins)];
channels.sourceBin = [1:numBins, 1:numBins];
channels.targetBin = [zeros(1, numBins), 1:numBins];
channels.mutationProbability = zeros(1, 2 * numBins);

sigma = modelParams.mutaDeviation;
probabilityMatrix = zeros(numBins);
channels.withinMutationMass = zeros(1, numBins);

for sourceBin = 1:numBins
    coverage = normcdf(binEdges(sourceBin + 1), ...
        binCenters(sourceBin), sigma) - ...
        normcdf(binEdges(sourceBin), binCenters(sourceBin), sigma);
    channels.withinMutationMass(sourceBin) = coverage;

    distance = 1;
    leftStopped = false;
    rightStopped = false;
    while coverage < algParams.mutationCoverageCutoff
        if leftStopped && rightStopped
            break
        end
        leftBin = sourceBin - distance;
        rightBin = sourceBin + distance;

        if ~leftStopped
            if leftBin >= 1
                probability = normcdf(binEdges(leftBin + 1), ...
                    binCenters(sourceBin), sigma) - ...
                    normcdf(binEdges(leftBin), ...
                    binCenters(sourceBin), sigma);
                probabilityMatrix(sourceBin, leftBin) = probability;
                coverage = coverage + probability;
            else
                coverage = coverage + normcdf(binEdges(1), ...
                    binCenters(sourceBin), sigma);
                leftStopped = true;
            end
        end

        if ~rightStopped
            if rightBin <= numBins
                probability = normcdf(binEdges(rightBin + 1), ...
                    binCenters(sourceBin), sigma) - ...
                    normcdf(binEdges(rightBin), ...
                    binCenters(sourceBin), sigma);
                probabilityMatrix(sourceBin, rightBin) = probability;
                coverage = coverage + probability;
            else
                coverage = coverage + 1 - normcdf(binEdges(end), ...
                    binCenters(sourceBin), sigma);
                rightStopped = true;
            end
        end
        distance = distance + 1;
    end
end

% Flatten row by row so cross-bin channels remain grouped by source bin.
allProbabilities = reshape(probabilityMatrix.', 1, []);
allSources = repelem(1:numBins, numBins);
allTargets = repmat(1:numBins, 1, numBins);
active = allProbabilities > 0;
crossProbabilities = allProbabilities(active);
crossSources = allSources(active);
crossTargets = allTargets(active);
identity = eye(numBins);

channels.stoichiometry = [channels.stoichiometry, ...
    identity(:, crossTargets)];
channels.typeCode = [channels.typeCode, repmat( ...
    channels.codes.crossMutation, 1, numel(crossSources))];
channels.sourceBin = [channels.sourceBin, crossSources];
channels.targetBin = [channels.targetBin, crossTargets];
channels.mutationProbability = [channels.mutationProbability, ...
    crossProbabilities];
channels.numBins = numBins;

numChannels = size(channels.stoichiometry, 2);
if numel(channels.typeCode) ~= numChannels || ...
        numel(channels.sourceBin) ~= numChannels || ...
        numel(channels.targetBin) ~= numChannels || ...
        numel(channels.mutationProbability) ~= numChannels || ...
        any(channels.sourceBin < 1 | channels.sourceBin > numBins)
    error('buildReactionChannels:InvalidMetadata', ...
        'Reaction-channel metadata are internally inconsistent.');
end
end

