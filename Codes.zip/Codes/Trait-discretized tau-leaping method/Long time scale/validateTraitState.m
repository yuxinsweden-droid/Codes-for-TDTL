function validateTraitState(binnedTraits, counts, binEdges)
%VALIDATETRAITSTATE Check continuous-trait storage against integer counts.
%
% This inexpensive final check is also called after every update when
% debugMode is true.  It detects negative/noninteger counts, lost traits,
% nonfinite values and traits stored in the wrong computational bin.

numBins = numel(binEdges) - 1;
if numel(binnedTraits) ~= numBins || numel(counts) ~= numBins
    error('validateTraitState:GridMismatch', ...
        'Trait cells, counts, and edges have inconsistent dimensions.');
end
if any(counts ~= cellfun(@numel, binnedTraits)) || ...
        any(counts < 0) || any(counts ~= round(counts))
    error('validateTraitState:CountMismatch', ...
        'Counts do not match retained exact traits.');
end
for bin = 1:numBins
    traits = binnedTraits{bin};
    if bin < numBins
        outside = traits < binEdges(bin) | traits >= binEdges(bin + 1);
    else
        outside = traits < binEdges(bin) | traits > binEdges(bin + 1);
    end
    if any(~isfinite(traits)) || any(outside)
        error('validateTraitState:InvalidTrait', ...
            'Bin %d contains a nonfinite or misplaced trait.', bin);
    end
end
end
