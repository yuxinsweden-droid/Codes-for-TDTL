function [binnedTraits, counts] = tauStep( ...
        binnedTraits, counts, channels, firingCounts, binEdges, ...
        binCenters, modelParams)
%TAUSTEP Apply one accepted leap while retaining continuous traits.
%
% Births use the population at the start of the leap. After all offspring
% reach their destination bins, deaths are sampled without replacement from
% the old individuals and newborns together in each bin.

firingCounts = reshape(double(firingCounts), [], 1);
if numel(firingCounts) ~= numel(channels.typeCode)
    error('tauStep:ChannelMismatch', ...
        'Firing counts and reaction-channel metadata differ.');
end
if any(~isfinite(firingCounts) | firingCounts < 0 | firingCounts ~= round(firingCounts))
    error('tauStep:InvalidFiring', 'Firing counts must be finite nonnegative integers.');
end

oldTraits = binnedTraits;
oldCounts = reshape(double(counts), 1, []);
expectedCounts = oldCounts + (channels.stoichiometry * firingCounts)';
if any(expectedCounts < 0)
    error('tauStep:NegativeFinalCount', 'A trait bin would have a negative final count.');
end
numBins = numel(oldCounts);
deathCounts = zeros(1, numBins);
additions = cell(1, numBins);

for eventIndex = reshape(find(firingCounts ~= 0), 1, [])
    number = firingCounts(eventIndex);
    sourceBin = channels.sourceBin(eventIndex);
    eventType = channels.typeCode(eventIndex);
    if eventType == channels.codes.death
        deathCounts(sourceBin) = deathCounts(sourceBin) + number;

    elseif oldCounts(sourceBin) == 0
        error('tauStep:InvalidFiring', 'A birth channel fired from an empty source bin.');

    elseif eventType == channels.codes.withinBirth
        selected = randi(oldCounts(sourceBin), 1, number);
        offspring = oldTraits{sourceBin}(selected);
        combinedMass = 1 - modelParams.mutaProb + ...
            modelParams.mutaProb .* ...
            channels.withinMutationMass(sourceBin);
        withinMutationProbability = modelParams.mutaProb .* ...
            channels.withinMutationMass(sourceBin) ./ combinedMass;
        mutationMask = rand(1, number) < withinMutationProbability;
        if any(mutationMask)
            means = repmat(binCenters(sourceBin), 1, nnz(mutationMask));
            offspring(mutationMask) = sampleTruncatedMutation(means, ...
                binEdges(sourceBin), binEdges(sourceBin + 1), ...
                modelParams.mutaDeviation);
        end
        additions{sourceBin} = [additions{sourceBin}, offspring];

    elseif eventType == channels.codes.crossMutation
        targetBin = channels.targetBin(eventIndex);
        means = repmat(binCenters(sourceBin), 1, number);
        offspring = sampleTruncatedMutation(means, ...
            binEdges(targetBin), binEdges(targetBin + 1), ...
            modelParams.mutaDeviation);
        additions{targetBin} = [additions{targetBin}, offspring];

    else
        error('tauStep:UnknownChannel', ...
            'A reaction channel has an unknown type code.');
    end
end

for bin = 1:numBins
    pool = [oldTraits{bin}, additions{bin}];
    if deathCounts(bin) > 0
        selected = randperm(numel(pool), deathCounts(bin));
        keep = true(1, numel(pool));
        keep(selected) = false;
        pool = pool(keep);
    end
    binnedTraits{bin} = pool;
end
counts = cellfun(@numel, binnedTraits);
if ~isequal(counts(:), expectedCounts(:))
    error('tauStep:CountMismatch', 'Surviving traits disagree with the sampled bin counts.');
end
end
