function [binEdges, binCenters, binnedTraits, counts] = ...
        initTraitGrid(numBins, traits, modelParams)
%INITTRAITGRID Assign continuous traits to the TDTL computational grid.
%
% The grid is an algorithmic approximation used for propensities and
% reaction channels.  The continuous values in traits are retained inside
% binnedTraits and are not replaced by bin centers.

binEdges = linspace(modelParams.traitMin, modelParams.traitMax, numBins + 1);
binCenters = 0.5 .* (binEdges(1:end-1) + binEdges(2:end));
[~, ~, binIndex] = histcounts(traits, binEdges);
if any(binIndex == 0)
    error('initTraitGrid:TraitOutsideDomain', ...
        'Every initial trait must lie inside the model domain.');
end
binnedTraits = cell(1, numBins);
for bin = 1:numBins
    binnedTraits{bin} = reshape(traits(binIndex == bin), 1, []);
end
counts = cellfun(@numel, binnedTraits);
validateTraitState(binnedTraits, counts, binEdges);
end
