function [birthRates, deathRates, rates] = computeRates( ...
        counts, binCenters, channels, modelParams)
%COMPUTERATES Model-specific bin-level reaction propensities.
%
% rates follows the exact ordering defined by channels.  A new model must
% replace this function together with buildReactionChannels.m and preserve
% one propensity per stoichiometry column.

counts = reshape(double(counts), 1, []);
numBins = numel(counts);
if numBins ~= channels.numBins || numel(binCenters) ~= numBins
    error('computeRates:GridMismatch', ...
        'Counts, centers and reaction channels use different grids.');
end

birthRates = modelParams.r .* exp( ...
    -((binCenters - modelParams.x0) .^ 2) ./ ...
    (2 .* modelParams.sigmaK .^ 2));
competition = exp(-((binCenters' - binCenters) .^ 2) ./ ...
    (2 .* modelParams.sigmaC .^ 2));
deathRates = modelParams.r ./ modelParams.K0 .* ...
    (competition * counts')';

rates = zeros(1, numel(channels.typeCode));
deathMask = channels.typeCode == channels.codes.death;
withinMask = channels.typeCode == channels.codes.withinBirth;
crossMask = channels.typeCode == channels.codes.crossMutation;

source = channels.sourceBin(deathMask);
rates(deathMask) = deathRates(source) .* counts(source);

source = channels.sourceBin(withinMask);
combinedWithinMass = 1 - modelParams.mutaProb + ...
    modelParams.mutaProb .* channels.withinMutationMass(source);
rates(withinMask) = birthRates(source) .* counts(source) .* ...
    combinedWithinMass;

source = channels.sourceBin(crossMask);
rates(crossMask) = birthRates(source) .* counts(source) .* ...
    channels.mutationProbability(crossMask) .* modelParams.mutaProb;

if numel(rates) ~= size(channels.stoichiometry, 2) || ...
        any(~isfinite(rates)) || any(rates < 0)
    error('computeRates:InvalidRate', ...
        'Reaction propensities are invalid or misaligned with channels.');
end
end

