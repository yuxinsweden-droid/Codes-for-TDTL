function offspring = sampleTruncatedMutation(meanTrait, leftEdge, rightEdge, sigma)
%SAMPLETRUNCATEDMUTATION Draw Gaussian mutations conditional on a target bin.
%
% The channel probability already accounts for the chance that a mutation
% lands in [leftEdge,rightEdge).  This inverse-CDF draw supplies its exact
% continuous trait conditional on that event.  Randomness comes from rand.

meanTrait = reshape(meanTrait, 1, []);
if sigma <= 0 || rightEdge <= leftEdge || any(~isfinite(meanTrait))
    error('sampleTruncatedMutation:InvalidInput', ...
        'Mutation means, deviation, or target interval are invalid.');
end
cdfLeft = normcdf((leftEdge - meanTrait) ./ sigma);
cdfRight = normcdf((rightEdge - meanTrait) ./ sigma);
width = cdfRight - cdfLeft;
if any(width <= 0 | ~isfinite(width))
    error('sampleTruncatedMutation:DegenerateInterval', ...
        'Target bin has zero mutation probability.');
end
u = cdfLeft + rand(size(meanTrait)) .* width;
u = min(max(u, eps), 1 - eps);
offspring = meanTrait + sigma .* norminv(u);
upperInterior = rightEdge - eps(max(1, abs(rightEdge)));
offspring = min(max(offspring, leftEdge), upperInterior);
end
