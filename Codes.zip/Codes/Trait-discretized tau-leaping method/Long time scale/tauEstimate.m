function [useTauLeap, tau, firingCounts, a0, candidateTau] = ...
        tauEstimate(rates, channels, counts, algParams, remainingTime)
%TAUESTIMATE Select a feasible leap or request exact Direct fallback.
%
% Critical classification uses the source population recorded for every
% channel.  It is independent of the switch requiring candidate tau > 10/a0.
% remainingTime defaults to Inf.  The untruncated candidate selects the
% method; a selected leap is capped before critical and Poisson sampling,
% even if that cap is below the switch threshold.  An infeasible capped leap
% is retried from half the capped interval, subject to the usual switch.
% candidateTau is the current selection estimate; tau is the accepted interval.

if nargin < 5
    remainingTime = Inf;
end
if ~isnumeric(remainingTime) || ~isreal(remainingTime) || ...
        ~isscalar(remainingTime) || isnan(remainingTime) || remainingTime < 0
    error('tauEstimate:InvalidRemainingTime', ...
        'remainingTime must be a nonnegative real scalar, or Inf.');
end

rates = reshape(double(rates), 1, []);
counts = reshape(double(counts), 1, []);
numBins = numel(counts);
stoichiometry = channels.stoichiometry;
numChannels = numel(rates);
if size(stoichiometry, 1) ~= numBins || ...
        size(stoichiometry, 2) ~= numChannels || ...
        numel(channels.sourceBin) ~= numChannels
    error('tauEstimate:ChannelMismatch', ...
        'Rates, state changes and channel metadata are inconsistent.');
end
a0 = sum(rates);
firingCounts = zeros(numChannels, 1);
useTauLeap = false;
tau = NaN;
candidateTau = 0;
if a0 <= 0 || remainingTime == 0
    return
end

populationPerChannel = counts(channels.sourceBin);
criticalEvents = find(populationPerChannel > 0 & ...
    populationPerChannel < algParams.nCritical);
noncriticalEvents = find(populationPerChannel >= algParams.nCritical);

drift = stoichiometry(:, noncriticalEvents) * ...
    rates(noncriticalEvents)';
variance = stoichiometry(:, noncriticalEvents) .^ 2 * ...
    rates(noncriticalEvents)';
scale = max([algParams.epsilon ./ 2 .* counts; ones(1, numBins)]);
bound1 = min(scale ./ abs(drift'), [], 'all');
bound2 = min(scale .^ 2 ./ variance', [], 'all');
candidateTau = min([bound1, bound2], [], 'all');
if isnan(candidateTau) || candidateTau < 0
    error('tauEstimate:InvalidCandidate', 'Candidate tau is invalid.');
end
switchThreshold = algParams.leapSwitchFactor ./ a0;
while candidateTau > switchThreshold
    boundedCandidate = min(candidateTau, remainingTime);
    firingCounts(:) = 0;
    if isempty(criticalEvents)
        tau = boundedCandidate;
    else
        criticalRate = sum(rates(criticalEvents));
        if criticalRate <= 0
            tau = boundedCandidate;
        else
            criticalTau = -log(max(rand, realmin)) ./ criticalRate;
            if boundedCandidate < criticalTau
                tau = boundedCandidate;
            else
                tau = criticalTau;
                selected = find(cumsum(rates(criticalEvents)) > ...
                    rand .* criticalRate, 1, 'first');
                firingCounts(criticalEvents(selected)) = 1;
            end
        end
    end

    if ~isempty(noncriticalEvents)
        firingCounts(noncriticalEvents) = poissrnd( ...
            rates(noncriticalEvents)' .* tau);
    end
    % Offspring entering each bin are available for deaths in this leap.
    proposedCounts = counts + (stoichiometry * firingCounts)';
    if all(proposedCounts >= 0)
        useTauLeap = true;
        return
    end
    candidateTau = boundedCandidate ./ 2;
end

tau = NaN;
firingCounts(:) = 0;
end
