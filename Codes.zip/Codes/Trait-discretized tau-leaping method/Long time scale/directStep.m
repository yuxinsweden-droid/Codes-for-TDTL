function [binnedTraits, counts, dt, eventOccurred] = directStep( ...
        rates, channels, binnedTraits, counts, binEdges, binCenters, ...
        modelParams, remainingTime, waitingTime)
%DIRECTSTEP Execute one exact reaction when a tau leap is not appropriate.
%
% This is the Direct-method fallback inside TDTL.  Reaction selection uses
% the channel metadata created by buildReactionChannels.  Continuous traits
% are retained even though propensities are evaluated on the trait grid.
%
% Randomness: draws one exponential waiting time, one reaction channel and,
% where needed, an individual parent and a truncated Gaussian mutation.
% remainingTime optionally caps the waiting interval (default Inf).  If the
% next event is later, only its waiting time is drawn: dt is capped and the
% state is unchanged.  eventOccurred distinguishes this terminal wait.
% A recording driver may supply a previously drawn waitingTime, after it
% has saved the pre-event state at observation times crossed by that wait.

if nargin < 8
    remainingTime = Inf;
end
if ~isnumeric(remainingTime) || ~isreal(remainingTime) || ...
        ~isscalar(remainingTime) || isnan(remainingTime) || remainingTime < 0
    error('directStep:InvalidRemainingTime', ...
        'remainingTime must be a nonnegative real scalar, or Inf.');
end
eventOccurred = false;
if remainingTime == 0
    dt = 0;
    return
end

rates = reshape(double(rates), 1, []);
if numel(rates) ~= numel(channels.typeCode)
    error('directStep:ChannelMismatch', ...
        'Rates and reaction-channel metadata have different lengths.');
end

a0 = sum(rates);
if a0 <= 0
    dt = remainingTime;
    return
end

if nargin < 9 || isempty(waitingTime)
    dt = -log(max(rand, realmin)) ./ a0;
else
    if ~isnumeric(waitingTime) || ~isreal(waitingTime) || ...
            ~isscalar(waitingTime) || isnan(waitingTime) || waitingTime < 0
        error('directStep:InvalidWaitingTime', ...
            'A supplied waitingTime must be a nonnegative real scalar.');
    end
    dt = waitingTime;
end
if dt > remainingTime
    dt = remainingTime;
    return
end
eventOccurred = true;
eventIndex = find(cumsum(rates) > rand .* a0, 1, 'first');
sourceBin = channels.sourceBin(eventIndex);
eventType = channels.typeCode(eventIndex);
if counts(sourceBin) <= 0
    error('directStep:EmptySource', ...
        'The selected reaction has an empty source bin.');
end

individual = randi(counts(sourceBin));
parentTrait = binnedTraits{sourceBin}(individual);

if eventType == channels.codes.death
    % A death removes one uniformly selected individual from its source bin.
    binnedTraits{sourceBin}(individual) = [];

elseif eventType == channels.codes.withinBirth
    % This channel combines clonal births and mutations that remain inside
    % the source bin.  Conditional sampling recovers the correct mixture.
    combinedMass = 1 - modelParams.mutaProb + ...
        modelParams.mutaProb .* channels.withinMutationMass(sourceBin);
    withinMutationProbability = modelParams.mutaProb .* ...
        channels.withinMutationMass(sourceBin) ./ combinedMass;
    if rand < withinMutationProbability
        offspring = sampleTruncatedMutation(binCenters(sourceBin), ...
            binEdges(sourceBin), binEdges(sourceBin + 1), ...
            modelParams.mutaDeviation);
    else
        offspring = parentTrait;
    end
    binnedTraits{sourceBin}(end + 1) = offspring;

elseif eventType == channels.codes.crossMutation
    % Cross-bin mutation channels store their destination explicitly.
    targetBin = channels.targetBin(eventIndex);
    offspring = sampleTruncatedMutation(binCenters(sourceBin), ...
        binEdges(targetBin), binEdges(targetBin + 1), ...
        modelParams.mutaDeviation);
    binnedTraits{targetBin}(end + 1) = offspring;

else
    error('directStep:UnknownChannel', ...
        'The selected reaction channel has an unknown type code.');
end

counts = cellfun(@numel, binnedTraits);
end
