function traits = initPopulation(traitDist)
%INITPOPULATION Create a row vector from a point or existing distribution.

switch lower(string(traitDist.type))
    case "point"
        traits = repmat(traitDist.value, 1, traitDist.numIndividuals);
    case "exist"
        traits = reshape(traitDist.trait, 1, []);
    otherwise
        error('initPopulation:UnknownType', 'Unknown initial distribution.');
end
end

