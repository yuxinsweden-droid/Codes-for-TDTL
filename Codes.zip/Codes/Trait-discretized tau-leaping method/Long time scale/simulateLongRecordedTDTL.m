function [traitSnapshots, diagnostics] = simulateLongRecordedTDTL( ...
        seed, totalTime, targetTimes, modelParams, algParams, binEdges, ...
        binCenters, initialBinnedTraits, initialCounts, channels, ...
        outputFile, debugMode)
%SIMULATELONGRECORDEDTDTL Run and atomically save one long TDTL repeat.
%
% Tau candidates are capped at the next observation before firings are
% sampled.  Exact fallback records pre-event states for crossed targets and
% retains its sampled wait.  Thus every snapshot belongs to its target time;
% actualTimes is not saved.  The observation grid affects tau step sizes.
%
% The repeat-level seed makes serial and parallel execution reproducible.

targetTimes = reshape(double(targetTimes), 1, []);
if ~isscalar(totalTime) || ~isfinite(totalTime) || totalTime < 0 || ...
        any(~isfinite(targetTimes)) || any(targetTimes < 0) || ...
        any(targetTimes > totalTime) || any(diff(targetTimes) <= 0)
    error('TDTLLong:InvalidObservationTimes', ...
        'Observation times must increase within [0,totalTime].');
end

rng(seed, 'twister');
binnedTraits = initialBinnedTraits;
counts = initialCounts;
traitSnapshots = cell(1, numel(targetTimes));
recordIndex = 1;
t = 0;
diagnostics = struct('tauSteps', 0, 'directSteps', 0, ...
    'tauFallbacks', 0);

[traitSnapshots, recordIndex] = recordReachedStates( ...
    traitSnapshots, recordIndex, targetTimes, t, binnedTraits);
while t < totalTime
    [~, ~, rates] = computeRates( ...
        counts, binCenters, channels, modelParams);
    if sum(rates) <= 0
        break
    end

    nextBoundary = totalTime;
    if recordIndex <= numel(targetTimes)
        nextBoundary = min(nextBoundary, targetTimes(recordIndex));
    end
    remainingTime = nextBoundary - t;
    [useTauLeap, tau, firingCounts] = tauEstimate( ...
        rates, channels, counts, algParams, remainingTime);
    if useTauLeap
        [binnedTraits, counts] = tauStep( ...
            binnedTraits, counts, channels, firingCounts, ...
            binEdges, binCenters, modelParams);
        if tau >= remainingTime
            t = nextBoundary;
        else
            t = t + tau;
        end
        diagnostics.tauSteps = diagnostics.tauSteps + 1;
        if debugMode
            validateTraitState(binnedTraits, counts, binEdges);
        end
        [traitSnapshots, recordIndex] = recordReachedStates( ...
            traitSnapshots, recordIndex, targetTimes, t, binnedTraits);
    else
        diagnostics.tauFallbacks = diagnostics.tauFallbacks + 1;
        for directIndex = 1:algParams.maxDirectSteps
            if t >= totalTime
                break
            end
            [~, ~, rates] = computeRates( ...
                counts, binCenters, channels, modelParams);
            if sum(rates) <= 0
                break
            end
            a0 = sum(rates);
            waitingTime = -log(max(rand, realmin)) ./ a0;
            remainingTime = totalTime - t;
            if waitingTime > remainingTime
                t = totalTime;
                break
            end
            eventTime = min(t + waitingTime, totalTime);
            if recordIndex <= numel(targetTimes) && ...
                    targetTimes(recordIndex) < eventTime
                preEventTraits = reshape([binnedTraits{:}], 1, []);
                while recordIndex <= numel(targetTimes) && ...
                        targetTimes(recordIndex) < eventTime
                    traitSnapshots{recordIndex} = preEventTraits;
                    recordIndex = recordIndex + 1;
                end
            end
            [binnedTraits, counts, dt, eventOccurred] = directStep( ...
                rates, channels, binnedTraits, counts, ...
                binEdges, binCenters, modelParams, remainingTime, waitingTime);
            if ~isfinite(dt) || dt < 0
                error('TDTLLong:InvalidDirectTime', ...
                    'Direct fallback returned an invalid time step.');
            end
            t = eventTime;
            diagnostics.directSteps = diagnostics.directSteps + eventOccurred;
            if debugMode
                validateTraitState(binnedTraits, counts, binEdges);
            end
            [traitSnapshots, recordIndex] = recordReachedStates( ...
                traitSnapshots, recordIndex, targetTimes, t, binnedTraits);
        end
    end
end

validateTraitState(binnedTraits, counts, binEdges);
while recordIndex <= numel(targetTimes)
    traitSnapshots{recordIndex} = reshape([binnedTraits{:}], 1, []);
    recordIndex = recordIndex + 1;
end

partFile = outputFile + ".part.mat";
save(partFile, 'traitSnapshots', 'targetTimes', 'seed', 'binEdges', '-v7.3');
movefile(partFile, outputFile, 'f');
end


function [snapshots, recordIndex] = recordReachedStates( ...
        snapshots, recordIndex, targetTimes, t, binnedTraits)
% Reached targets are leap endpoints or exactly coincident fallback events.
while recordIndex <= numel(targetTimes) && t >= targetTimes(recordIndex)
    snapshots{recordIndex} = reshape([binnedTraits{:}], 1, []);
    recordIndex = recordIndex + 1;
end
end
