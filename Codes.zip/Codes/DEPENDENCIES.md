# Dependencies and resource requirements

## Software

- MATLAB R2024a is the tested release.
- Statistics and Machine Learning Toolbox is required for `normcdf`,
  `norminv`, `normrnd`, and `poissrnd`.
- Parallel Computing Toolbox is optional.  Formal runs strongly benefit from
  it, but every simulation has a serial fallback controlled by `useParallel`.
- No Communications Toolbox function is used.  In particular, Bernoulli
  mutation decisions use `rand` rather than `randsrc`.
- No third-party MATLAB package, Python package, compiled library, or code
  outside `Codes` is required.

Run `checkDependencies` to inspect the active MATLAB installation.

## Storage and memory

Formal short-time calculations retain continuous terminal traits for 100,000
replicates at each of 20 initial states.  Formal long-time calculations retain
10,001 continuous-trait snapshots for each of 400 repeats per method.  Actual
file sizes depend on population size and MATLAB compression; plan for tens of
gigabytes of free disk space (50 GB or more is recommended).

Large output files are written with MAT-file format `-v7.3`.  W1 processes one
short-time initial state or a small block of long-time snapshots at a time, but
exact ECDF construction still benefits from at least 16 GB RAM; 32 GB or more
is recommended for the formal 100,000-repeat short-time analysis.

Wall time is hardware- and trajectory-dependent.  Smoke tests should finish
quickly, but the formal short study contains two million repeats per method
and the formal long study contains 400 long trajectories per method.  These
are multi-hour to multi-day workloads on typical workstations and can take
longer in serial.  Before a formal run, time 10--100 representative repeats,
multiply by the requested repeat count, and include metric-processing time.

## Parallel execution

`useParallel = true` requests a local process pool.  If the Parallel Computing
Toolbox or a valid license is unavailable, the program prints a warning and
uses a deterministic serial loop.  Seeds are set inside each repeat, so worker
count and scheduling do not alter a repeat's output.
