# Applying the framework to a new model

The supplied MATLAB programs are a worked implementation for the
one-dimensional Dieckmann-Doebeli example.  That example has birth, death and
mutation events, but those features do not define the full scope of the
framework.  The reusable idea is to represent a continuous individual state
by finite bin or cell counts, express stochastic events as reaction channels,
and apply tau leaping to that count vector while retaining individual-level
continuous values when they are needed.

## 1. Decide whether the framework fits

The Direct method applies to a continuous-time Markov event model once all
events and propensities are defined.  The trait-discretized tau-leaping method
is a suitable starting point when:

1. individuals carry one or more continuous attributes that affect event
   propensities or event outcomes;
2. the relevant continuous domain can be partitioned into a finite collection
   of bins or cells;
3. the binned state can be updated through reaction channels, each with a
   propensity and a state-change vector;
4. auxiliary random event outcomes can be represented by probabilities over
   discrete sub-channels; and
5. propensities remain approximately constant over an accepted leap.

The continuous attribute need not be produced by mutation and need not be
interpreted as a genetic trait.  It may represent any scientifically relevant
continuous individual coordinate for which bin- or cell-level rate evaluation
is acceptable.  A model containing only demographic or ecological events can
therefore use the same construction.  Mutation in the supplied example is one
instance of a more general stochastic-outcome transition.

A genuinely non-Markov model is not made Markov by discretization.  It must
first be reformulated by augmenting the state with the required history or
duration variables, or simulated with a method appropriate to its waiting-time
structure.

## 2. Write the stochastic model before editing code

Specify:

1. the complete individual-level and population-level state;
2. every event and its state change;
3. every event propensity;
4. any conditional outcome or transition distribution;
5. valid state boundaries and conservation rules;
6. initial conditions, observation times and desired outputs.

Separate event mechanisms from the example's biological labels.  A channel
may describe birth or death, but it may also describe immigration, emigration,
phenotype switching, movement between classes, recruitment, removal, or
another Markov event.  What matters to the algorithm is its propensity and its
effect on the discretized state.

## 3. Choose the discretized state representation

### One continuous coordinate

Partition the coordinate into bins and let each state entry be the number of
individuals in one bin.  This is the representation used in the supplied
Dieckmann-Doebeli programs.

### Multiple continuous coordinates

For a vector-valued individual state, partition the multidimensional domain
into cells.  A cell is identified by a multi-index
`(i1, i2, ..., id)`, but tau selection does not require a multidimensional
MATLAB array.  Map each occupied cell to one linear index and store all cell
counts in a one-dimensional vector.  For a full rectangular grid, MATLAB's
column-major mapping can be written as

```text
q = 1 + sum_k (ik - 1) product_(l<k) Nl,
```

where `Nk` is the number of intervals along coordinate `k`.  Reaction
stoichiometry and propensities then use the linear index `q`.  This flattening
is an exact computational representation of the chosen multidimensional grid;
it does not remove biological dimensions or information.

For large or sparsely occupied grids, storing only active cells can avoid the
full product of all `Nk`, provided that channel indexing and state validation
are redesigned consistently.

### Scientific projection to one coordinate

A high-dimensional individual state may instead be mapped to a scalar
coordinate `u = g(z)` before discretization.  This is a true dimensionality
reduction and can greatly reduce the number of cells and reaction channels.
It is valid only when the projected coordinate retains the information needed
to approximate the propensities and conditional event outcomes.  Compare the
projected model with the full Direct model and test whether individuals with
the same `u` but different omitted coordinates have materially different
rates.  If they do, use multidimensional cells or enrich the projected state.

### Multiple species or state blocks

Give each species or discrete class its own bin/cell block, then stack the
blocks into one joint count vector.  Cross-species events are reaction channels
whose state-change vectors touch more than one block.  Again, stacking is an
indexing operation rather than a biological assumption.

The one-dimensional arrays used by the tau-selection routines therefore do
not limit the underlying model to one biological dimension.

## 4. Define reaction channels by update type

For a deterministic-update channel, selecting the channel fixes its change to
the binned count vector.  Birth, death and many within- or between-class
transitions have this form.

For a stochastic-outcome event, the event type alone does not fix the outcome.
Expand its possible outcomes into sub-channels with deterministic count
changes and propensities weighted by their conditional probabilities.  The
mutation source-to-destination channels in this package are one example.  The
same pattern can represent another transition kernel or a discrete auxiliary
choice, provided that the required outcome probabilities can be calculated.

If continuous individual records are retained, every accepted direct event or
leap must update both representations and preserve

```text
number of retained individuals in each bin/cell
    = corresponding entry of the count vector.
```

## 5. Choose the adaptation level

### Level A: same state and channel layout

If only the propensity formulas or parameter values change, retain the event
engine and replace both `computeRates.m` and the matching Direct
`updateRatesAfterEvent.m`. If rates cannot be maintained by a local incremental
update, replace that update with the model's correct full rate recomputation.
Update the state validator and add
hand-calculated rate tests.

### Level B: new events on the same one-dimensional grid

Rebuild reaction-channel metadata and event application.  The tau-selection,
critical-channel, feasibility-retry and Direct-fallback structure can usually
remain if the channel contract is preserved.

### Level C: multidimensional cells, stacked species or a scalar projection

Redesign grid construction, linear indexing, channel construction, event
application, saved outputs and validation.  The count vector passed to tau
selection can remain one-dimensional.  For a scalar projection, add explicit
tests of projection error against the unreduced Direct model.

### Level D: incompatible process assumptions

History-dependent waiting times, events that cannot be represented by the
chosen finite state, or dynamics for which propensities change substantially
within every useful leap require state augmentation or a different simulation
scheme.  Changing only parameter values is not sufficient.

## 6. Direct-method file map

Copy one complete Direct method folder and review:

| File | Role | Action for a new model |
|---|---|---|
| `main.m` | visible model, algorithm, study and runtime settings | replace model and study sections |
| `initPopulation.m` (Long) or the `baseTraits.mat` loader (Short) | initial state construction | extend if the state format changes |
| `computeRates.m` | exact event propensities | replace |
| `updateRatesAfterEvent.m` | model-specific incremental rate update after an accepted event | replace consistently with computeRates |
| `simulateStep.m` | exact event selection and application | retain only when the event layout and outcome rules match |
| `simulateDirectRepeat.m` or `simulateLongDirectRepeat.m` | seeded experiment driver | adapt outputs and stopping/recording rules |
| `validateDirectState.m` | state invariants | update all domain, block and conservation checks |
| `Tests/runAllSmokeTests.m` and its test scripts | reduced reproducibility tests | add hand-checkable events, full-rate audits and boundary cases |

The current `simulateStep.m` implements the example's birth, death and
mutation semantics.  Its cumulative-rate event selection is reusable, but a
new event catalogue requires corresponding selection and application logic.

`algParams.bufferGrowth` is an implementation setting.  It must not enter any
propensity.  Runs with different positive values should produce the same
active state for the same seed.

## 7. TDTL file map

Copy one complete TDTL folder and review:

| File | Role | Action for a new model |
|---|---|---|
| `main.m` | all visible settings | replace model/study sections and tune numerical settings |
| `initTraitGrid.m` | continuous-state to grid mapping | replace for new bins, cells, blocks or projection |
| `buildReactionChannels.m` | stoichiometry and channel metadata | replace when events or indexing change |
| `computeRates.m` | bin/cell-level propensities in channel order | replace and preserve channel alignment |
| `tauEstimate.m` | critical/noncritical selection and candidate tau | retain when the finite count-vector contract applies |
| `directStep.m` | exact fallback event application | modify for new channel outcomes |
| `tauStep.m` | leap event application | modify for new channel outcomes |
| `sampleTruncatedMutation.m` | example-specific conditional outcome sampler | remove or replace when the outcome law is not mutation |
| `validateTraitState.m` | count/individual/grid invariants | replace for the new representation |

The names `initTraitGrid` and `sampleTruncatedMutation` reflect this example;
they are not requirements of the general reaction-channel construction.

For every model, verify:

```text
number of rate entries
    = number of stoichiometry columns
    = number of channel-type entries
    = number of source-state entries.
```

Any target-state or conditional-outcome metadata must have the same channel
ordering.

## 8. Separate model, algorithm and study settings

Keep these sections distinct in `main.m`:

```matlab
%% Model-specific parameters
modelParams = ...;

%% Algorithm and discretization settings
algParams.bufferGrowth = ...;  % Direct only
algParams.numTraitBins = ...;  % current 1D TDTL example
algParams.epsilon = ...;       % TDTL

%% Study-specific settings
totalTime = ...;
repeatTimes = ...;
targetTimes = ...;

%% Runtime and reproducibility settings
baseSeed = ...;
useParallel = ...;
debugMode = ...;
```

For a multidimensional grid, replace `numTraitBins` by per-coordinate grid
sizes and an explicit multi-index-to-linear-index rule.  Do not copy the
supplied repeat counts, time horizons, grid resolution or tau tolerance
without checking them for the new model.

Choose and validate the observation grid explicitly. Exact Direct recording
preserves the sampled next event and reports the state at each target. TDTL
caps candidate leaps at the next observation before sampling firings, so its
recording interval also constrains the numerical step. Use the same target
times for accuracy/runtime comparisons, and never apply an event after the
stated terminal time.

## 9. Validation sequence

1. Test propensity values against a hand-calculated small state.
2. Test every channel's count change and individual-level outcome separately.
3. Run one Direct repeat twice with the same seed.
4. Confirm serial and parallel results match by repeat seed.
5. Verify channel rates, metadata and stoichiometry have identical ordering.
6. Check count nonnegativity and individual/count consistency after every
   step in debug mode.
7. Compare TDTL with Direct at reduced scale.
8. Refine every grid coordinate and decrease `epsilon` until conclusions are
   stable.
9. For a scalar projection, compare with the unreduced Direct state and test
   sensitivity to the projection definition.
10. Inspect tau-leap, rejected-leap and Direct-fallback frequencies.
11. Only then choose the formal horizon and repeat count.

For multidimensional grids, also test the forward and inverse index mappings,
cell-boundary assignment and channels that change more than one state block.

## 10. Metrics are a separate design choice

The supplied W1 and MHE functions reproduce this study's one-dimensional
comparison; they do not define the scope of the simulation algorithms.  W1
may still be used for a scientifically meaningful scalar coordinate or
projection.  A multidimensional state can instead be assessed coordinate by
coordinate, through justified one-dimensional projections, or with a chosen
multidimensional distribution metric.  State clearly which information each
choice retains.

The supplied MHE assumes a common one-dimensional trait grid.  A cell-based or
multi-species model requires a revised implementation that compares matched
cells or state blocks.  Validate the metric separately from the simulator.
