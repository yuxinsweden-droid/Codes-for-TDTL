function testSimulationTimes(codesRoot)
%TESTSIMULATIONTIMES Audit endpoint guards and state-at-time recording.
% All written files are temporary; formal simulation data are never used.
if nargin == 0
    codesRoot = fileparts(fileparts(mfilename('fullpath')));
end
oldPath = path;
pathGuard = onCleanup(@() path(oldPath)); %#ok<NASGU>
temporaryRoot = tempname;
mkdir(temporaryRoot);
tempGuard = onCleanup(@() rmdir(temporaryRoot, 's')); %#ok<NASGU>
addpath(fullfile(codesRoot, 'Tests', 'ReferenceDirect'));

directFolders = {fullfile(codesRoot, 'Direct method', 'Short time scale'), ...
    fullfile(codesRoot, 'Direct method', 'Long time scale'), ...
    fullfile(codesRoot, 'Starter')};
p = modelParameters();
alg.bufferGrowth = 7;
edges = linspace(-0.5, 0.5, 20);
traits = [-0.3, 0.1, 0.2];
for copyIndex = 1:numel(directFolders)
    selectFolder(directFolders{copyIndex});
    x = [traits, zeros(1, alg.bufferGrowth)];
    n = numel(traits);
    b = zeros(size(x)); d = b;
    [b(1:n), d(1:n)] = computeRates(traits, n, p);
    rng(90, 'twister');
    [expectedX, expectedN, wait, expectedB, expectedD, occurred] = ...
        simulateStep(n, x, b, d, p, alg);
    expectedRng = rng;
    assert(occurred && expectedN ~= n);

    % A crossing draws only its wait; no event, mutation, or rate update.
    rng(90, 'twister');
    rand;
    waitOnlyRng = rng;
    rng(90, 'twister');
    [actualX, actualN, dt, actualB, actualD, occurred] = ...
        simulateStep(n, x, b, d, p, alg, wait / 2);
    assert(~occurred && dt == wait/2 && actualN == n);
    assert(isequal(actualX, x) && isequal(actualB, b) && isequal(actualD, d));
    assert(isequal(rng, waitOnlyRng));
    for horizon = [wait, 2*wait]
        rng(90, 'twister');
        [actualX, actualN, dt, actualB, actualD, occurred] = ...
            simulateStep(n, x, b, d, p, alg, horizon);
        assert(occurred && dt == wait && actualN == expectedN);
        assert(isequal(actualX, expectedX) && isequal(actualB, expectedB) && ...
            isequal(actualD, expectedD) && isequal(rng, expectedRng));
    end
    rng(90, 'twister');
    beforeRng = rng;
    [actualX, actualN, dt, actualB, actualD, occurred] = ...
        simulateStep(n, x, b, d, p, alg, 0);
    assert(~occurred && dt == 0 && actualN == n && isequal(rng, beforeRng));
    assert(isequal(actualX, x) && isequal(actualB, b) && isequal(actualD, d));
    rng(90, 'twister');
    sampledWait = -log(max(rand, realmin)) / (sum(d(1:n)) + sum(b(1:n)));
    [actualX, actualN, ~, ~, ~, occurred] = ...
        simulateStep(n, x, b, d, p, alg, Inf, sampledWait);
    assert(occurred && actualN == expectedN && isequal(actualX, expectedX));
    assert(isequal(rng, expectedRng));
    % The recording driver supplies a wait once; rejecting it draws nothing.
    beforeRng = rng;
    [actualX, actualN, dt, actualB, actualD, occurred] = ...
        simulateStep(n, x, b, d, p, alg, wait/2, sampledWait);
    assert(~occurred && dt == wait/2 && actualN == n);
    assert(isequal(actualX, x) && isequal(actualB, b) && isequal(actualD, d));
    assert(isequal(rng, beforeRng));
    [actualX, actualN, dt, ~, ~, occurred] = ...
        simulateStep(n, x, zeros(size(b)), zeros(size(d)), p, alg, 0.5);
    assert(~occurred && dt == 0.5 && actualN == n && isequal(actualX, x));
    assertError(@() simulateStep(n, x, b, d, p, alg, -1), ...
        'simulateStep:InvalidRemainingTime');
    rmpath(directFolders{copyIndex});
end

% Short endpoints and absorbing states.
selectFolder(directFolders{1});
for horizon = [0, 1e-12, 0.2]
    actual = simulateDirectRepeat(traits, 90, horizon, p, alg, edges, true);
    expected = simulateDirectRepeatReference(traits, 90, horizon, ...
        p, alg, edges, false);
    assert(isequal(actual, expected));
end
inactive = p; inactive.r = 0;
actual = simulateDirectRepeat(traits, 90, 1, inactive, alg, edges, true);
assert(isequal(actual, traits));
rmpath(directFolders{1});

% Long Direct snapshots equal independent exact terminal runs at each target.
selectFolder(directFolders{2});
[b, d] = computeRates(traits, numel(traits), p);
rng(90, 'twister');
wait = -log(max(rand, realmin)) / (sum(d) + sum(b));
targets = [0, wait/2, wait, 1.5*wait, 2*wait];
actual = simulateLongDirectRepeat(traits, 90, targets(end), targets, ...
    p, alg, fullfile(temporaryRoot, 'direct_times.mat'), true);
denseRng = rng;
assert(isequal(actual{2}, traits) && ~isequal(actual{3}, traits));
for index = 1:numel(targets)
    expected = simulateDirectRepeatReference(traits, 90, targets(index), ...
        p, alg, edges, false);
    assert(isequal(actual{index}, expected));
end
coarse = simulateLongDirectRepeat(traits, 90, targets(end), ...
    [0, targets(end)], p, alg, fullfile(temporaryRoot, 'direct_coarse.mat'), true);
assert(isequal(coarse{end}, actual{end}) && isequal(rng, denseRng));
zero = simulateLongDirectRepeat(traits, 90, 0, 0, p, alg, ...
    fullfile(temporaryRoot, 'direct_zero.mat'), true);
assert(isequal(zero{1}, traits));
inactiveStates = simulateLongDirectRepeat(traits, 90, 1, [0, 0.5, 1], ...
    inactive, alg, fullfile(temporaryRoot, 'direct_inactive.mat'), true);
assert(all(cellfun(@(x) isequal(x, traits), inactiveStates)));
emptyStates = simulateLongDirectRepeat([], 90, 1, [0, 0.5, 1], p, alg, ...
    fullfile(temporaryRoot, 'direct_empty.mat'), true);
assert(all(cellfun(@isempty, emptyStates)));
deathOnly = p; deathOnly.x0 = 1e6;
[~, d] = computeRates(0.2, 1, deathOnly);
rng(7, 'twister');
deathTime = -log(max(rand, realmin)) / sum(d);
extinct = simulateLongDirectRepeat(0.2, 7, 2*deathTime, ...
    [0, deathTime/2, deathTime, 2*deathTime], deathOnly, alg, ...
    fullfile(temporaryRoot, 'direct_extinct.mat'), true);
assert(isequal(extinct{2}, 0.2) && isempty(extinct{3}) && isempty(extinct{4}));
rmpath(directFolders{2});

tdtlFolders = {fullfile(codesRoot, 'Trait-discretized tau-leaping method', ...
    'Short time scale'), fullfile(codesRoot, ...
    'Trait-discretized tau-leaping method', 'Long time scale')};
tdtlAlg = tauParameters();
for copyIndex = 1:numel(tdtlFolders)
    selectFolder(tdtlFolders{copyIndex});
    testTauBounds(tdtlAlg);
    testFinalBinCounts(p, tdtlAlg);
    [binEdges, centers, binned, counts] = initTraitGrid(1, traits, p);
    channels = buildReactionChannels(binEdges, centers, p, tdtlAlg);
    [~, ~, rates] = computeRates(counts, centers, channels, p);
    rng(90, 'twister');
    [expectedTraits, expectedCounts, wait, occurred] = directStep( ...
        rates, channels, binned, counts, binEdges, centers, p);
    expectedRng = rng;
    assert(occurred);
    rng(90, 'twister'); rand; waitOnlyRng = rng;
    rng(90, 'twister');
    [actualTraits, actualCounts, dt, occurred] = directStep( ...
        rates, channels, binned, counts, binEdges, centers, p, wait/2);
    assert(~occurred && dt == wait/2 && isequal(actualTraits, binned));
    assert(isequal(actualCounts, counts) && isequal(rng, waitOnlyRng));
    for horizon = [wait, 2*wait]
        rng(90, 'twister');
        [actualTraits, actualCounts, dt, occurred] = directStep( ...
            rates, channels, binned, counts, binEdges, centers, p, horizon);
        assert(occurred && dt == wait && isequal(actualTraits, expectedTraits));
        assert(isequal(actualCounts, expectedCounts) && isequal(rng, expectedRng));
    end
    rng(90, 'twister'); beforeRng = rng;
    [actualTraits, actualCounts, dt, occurred] = directStep( ...
        rates, channels, binned, counts, binEdges, centers, p, 0);
    assert(~occurred && dt == 0 && isequal(rng, beforeRng));
    assert(isequal(actualTraits, binned) && isequal(actualCounts, counts));
    rng(90, 'twister');
    sampledWait = -log(max(rand, realmin)) / sum(rates);
    [actualTraits, actualCounts] = directStep( ...
        rates, channels, binned, counts, binEdges, centers, p, Inf, sampledWait);
    assert(isequal(actualTraits, expectedTraits) && ...
        isequal(actualCounts, expectedCounts) && isequal(rng, expectedRng));
    beforeRng = rng;
    [actualTraits, actualCounts, dt, occurred] = directStep( ...
        rates, channels, binned, counts, binEdges, centers, p, wait/2, sampledWait);
    assert(~occurred && dt == wait/2 && isequal(actualTraits, binned));
    assert(isequal(actualCounts, counts) && isequal(rng, beforeRng));
    rmpath(tdtlFolders{copyIndex});
end

% Pure exact fallback has the same path on sparse and dense recording grids.
selectFolder(tdtlFolders{2});
[binEdges, centers, binned, counts] = initTraitGrid(1, traits, p);
channels = buildReactionChannels(binEdges, centers, p, tdtlAlg);
[~, ~, rates] = computeRates(counts, centers, channels, p);
rng(90, 'twister');
wait = -log(max(rand, realmin)) / sum(rates);
fallbackAlg = tdtlAlg; fallbackAlg.leapSwitchFactor = Inf;
targets = [0, wait/2, wait, 1.5*wait, 2*wait];
[actual, diagnostics] = simulateLongRecordedTDTL(90, targets(end), ...
    targets, p, fallbackAlg, binEdges, centers, binned, counts, channels, ...
    fullfile(temporaryRoot, 'fallback_dense.mat'), true);
denseRng = rng;
assert(isequal(actual{2}, traits) && ~isequal(actual{3}, traits));
[coarse, coarseDiagnostics] = simulateLongRecordedTDTL(90, targets(end), ...
    [0, targets(end)], p, fallbackAlg, binEdges, centers, binned, counts, ...
    channels, fullfile(temporaryRoot, 'fallback_coarse.mat'), true);
assert(isequal(actual{end}, coarse{end}) && isequal(rng, denseRng));
assert(diagnostics.directSteps == coarseDiagnostics.directSteps);
for index = 1:numel(targets)
    expected = terminalFallback(90, targets(index), p, binEdges, centers, ...
        binned, counts, channels);
    assert(isequal(actual{index}, expected));
end
[tiny, diagnostics] = simulateLongRecordedTDTL(90, 1e-12, [0, 1e-12], ...
    p, fallbackAlg, binEdges, centers, binned, counts, channels, ...
    fullfile(temporaryRoot, 'fallback_tiny.mat'), true);
assert(isequal(tiny{end}, traits) && diagnostics.directSteps == 0);
[zero, diagnostics] = simulateLongRecordedTDTL(90, 0, 0, p, tdtlAlg, ...
    binEdges, centers, binned, counts, channels, ...
    fullfile(temporaryRoot, 'tdtl_zero.mat'), true);
assert(isequal(zero{1}, traits) && diagnostics.tauSteps == 0 && ...
    diagnostics.directSteps == 0);
inactiveStates = simulateLongRecordedTDTL(90, 1, [0, 0.5, 1], inactive, ...
    tdtlAlg, binEdges, centers, binned, counts, channels, ...
    fullfile(temporaryRoot, 'tdtl_inactive.mat'), true);
assert(all(cellfun(@(x) isequal(x, traits), inactiveStates)));
[~, ~, emptyBinned, emptyCounts] = initTraitGrid(1, [], p);
emptyStates = simulateLongRecordedTDTL(90, 1, [0, 0.5, 1], p, tdtlAlg, ...
    binEdges, centers, emptyBinned, emptyCounts, channels, ...
    fullfile(temporaryRoot, 'tdtl_empty.mat'), true);
assert(all(cellfun(@isempty, emptyStates)));
[~, ~, deathBinned, deathCounts] = initTraitGrid(1, 0.2, deathOnly);
extinct = simulateLongRecordedTDTL(7, 2*deathTime, ...
    [0, deathTime/2, deathTime, 2*deathTime], deathOnly, fallbackAlg, ...
    binEdges, centers, deathBinned, deathCounts, channels, ...
    fullfile(temporaryRoot, 'tdtl_extinct.mat'), true);
assert(isequal(extinct{2}, 0.2) && isempty(extinct{3}) && isempty(extinct{4}));

% An actual tau leap must sample at the first observation, not at its larger
% unconstrained candidate. Here all retained traits remain zero; its first
% population size is independently determined by two Poisson draws.
manyTraits = zeros(1, 100);
[~, ~, manyBinned, manyCounts] = initTraitGrid(1, manyTraits, p);
[~, ~, rates] = computeRates(manyCounts, centers, channels, p);
leapAlg = tdtlAlg; leapAlg.epsilon = 1;
firstTarget = 0.02; % Less than 10/a0: still use the originally selected leap.
rng(17, 'twister');
expectedFirings = poissrnd(rates(:) * firstTarget);
expectedCount = 100 + channels.stoichiometry * expectedFirings;
[leapStates, diagnostics] = simulateLongRecordedTDTL(17, 0.04, ...
    [0, firstTarget, 0.04], p, leapAlg, binEdges, centers, manyBinned, ...
    manyCounts, channels, fullfile(temporaryRoot, 'tdtl_leap.mat'), true);
assert(diagnostics.tauSteps == 2 && diagnostics.directSteps == 0 && ...
    diagnostics.tauFallbacks == 0 && numel(leapStates{2}) == expectedCount);
rmpath(tdtlFolders{2});

selectFolder(tdtlFolders{1});
for horizon = [0, 1e-12, 0.2]
    [actual, ~, diagnostics] = simulateRecordedTDTL(90, horizon, p, ...
        fallbackAlg, binEdges, centers, binned, counts, channels, true);
    expected = terminalFallback(90, horizon, p, binEdges, centers, ...
        binned, counts, channels);
    assert(isequal(actual, expected));
    if horizon < 1e-10
        assert(diagnostics.directSteps == 0 && diagnostics.tauSteps == 0);
    end
end
% A final cap below 10/a0 is a leap, even when no reaction fires in it.
[tinyLeap, tinyCounts, diagnostics] = simulateRecordedTDTL(90, 1e-12, ...
    p, leapAlg, binEdges, centers, manyBinned, manyCounts, channels, true);
assert(isequal(tinyLeap, manyTraits) && isequal(double(tinyCounts), manyCounts));
assert(diagnostics.tauSteps == 1 && diagnostics.directSteps == 0 && ...
    diagnostics.tauFallbacks == 0);
rmpath(tdtlFolders{1});
fprintf('All terminal-time and observation-time audits passed.\n');
end


function testTauBounds(alg)
simple = simpleChannels();
% No critical channels: check the exact capped Poisson draws and RNG state.
rng(17, 'twister');
expectedFirings = poissrnd([1; 1]*6);
expectedRng = rng;
rng(17, 'twister');
[useLeap, tau, firings, ~, candidate] = tauEstimate([1, 1], simple, 100, alg, 6);
assert(useLeap && tau == 6 && candidate == 12.5);
assert(isequal(firings, expectedFirings) && isequal(rng, expectedRng));
% Selection uses 12.5, then the accepted interval is capped below 10/a0=5.
rng(17, 'twister');
expectedFirings = poissrnd([1; 1]*0.1);
expectedRng = rng;
rng(17, 'twister');
[useLeap, tau, firings, ~, candidate] = tauEstimate([1, 1], simple, 100, alg, 0.1);
assert(useLeap && tau == 0.1 && candidate == 12.5);
assert(isequal(firings, expectedFirings) && isequal(rng, expectedRng));
% An originally small candidate still requests Direct without firing draws.
beforeRng = rng;
[useLeap, ~, firings, ~, candidate] = tauEstimate([1, 1], simple, 2, alg, 0.1);
assert(~useLeap && candidate == 0.5 && all(firings == 0));
assert(isequal(rng, beforeRng));
[useLeap, ~, firings] = tauEstimate([1, 1], simple, 100, alg, 0);
assert(~useLeap && all(firings == 0) && isequal(rng, beforeRng));
assertError(@() tauEstimate([1, 1], simple, 100, alg, NaN), ...
    'tauEstimate:InvalidRemainingTime');

critical = simple;
critical.stoichiometry = [-1, 0; 0, 1];
critical.sourceBin = [1, 2]; critical.targetBin = [0, 2];
critical.withinMutationMass = [0, 0]; critical.numBins = 2;
wide = alg; wide.epsilon = 1;
% A critical event after the boundary must not be forced into the leap.
rng(1, 'twister');
criticalWait = -log(max(rand, realmin)) / 0.01;
assert(criticalWait > 6);
expectedBirths = poissrnd(2*6); expectedRng = rng;
rng(1, 'twister');
[useLeap, tau, firings] = tauEstimate([0.01, 2], critical, [1, 100], wide, 6);
assert(useLeap && tau == 6 && isequal(firings, [0; expectedBirths]));
assert(isequal(rng, expectedRng));
% An in-interval critical event is included, including exact equality.
rng(1, 'twister'); criticalWait = -log(max(rand, realmin));
rng(1, 'twister');
[useLeap, tau, firings] = tauEstimate([1, 2], critical, [1, 100], wide, 6);
assert(useLeap && tau == criticalWait && firings(1) == 1);
rng(1, 'twister');
[useLeap, tau, firings] = tauEstimate( ...
    [1, 2], critical, [1, 100], wide, criticalWait);
assert(useLeap && tau == criticalWait && firings(1) == 1);

% Independently reproduce rejected Poisson leaps from the CAPPED interval.
retry = alg; retry.epsilon = 100;
acceptedSeen = false; fallbackSeen = false;
for seed = 1:20
    rng(seed, 'twister');
    trial = 1; threshold = retry.leapSwitchFactor / 100;
    expectedUseLeap = false; expectedTau = NaN; expectedFirings = [0; 0];
    while trial > threshold
        draw = poissrnd([100; 0]*trial);
        if trial == 1
            assert(draw(1) > 10);
        end
        if draw(1) <= 10
            expectedUseLeap = true; expectedTau = trial; expectedFirings = draw;
            break
        end
        trial = trial/2;
    end
    expectedRng = rng;
    rng(seed, 'twister');
    [useLeap, tau, firings, ~, candidate] = tauEstimate( ...
        [100, 0], simple, 10, retry, 1);
    assert(useLeap == expectedUseLeap && isequaln(tau, expectedTau));
    assert(candidate == trial && isequal(firings, expectedFirings));
    assert(isequal(rng, expectedRng));
    acceptedSeen = acceptedSeen || useLeap;
    fallbackSeen = fallbackSeen || ~useLeap;
end
assert(acceptedSeen && fallbackSeen);

% A failed boundary leap starts its retry at half the cap. Since that is
% below the original switch threshold, it returns Direct after one draw.
cap = 0.09;
for seed = 1:100
    rng(seed, 'twister');
    draw = poissrnd([100; 0]*cap);
    if draw(1) > 10
        break
    end
end
assert(draw(1) > 10);
expectedRng = rng;
rng(seed, 'twister');
[useLeap, tau, firings, ~, candidate] = tauEstimate( ...
    [100, 0], simple, 10, retry, cap);
assert(~useLeap && isnan(tau) && candidate == cap/2 && all(firings == 0));
assert(isequal(rng, expectedRng));
end


function testFinalBinCounts(p, alg)
% Only deaths in bin 2 and births from bin 1 into bin 2 have positive rates.
alg.numTraitBins = 2;
alg.epsilon = 4;
p.mutaProb = 1;
p.mutaDeviation = 0.2;
[edges, centers, binned, counts] = initTraitGrid(2, [-0.4, -0.1, 0.2, 0.4], p);
channels = buildReactionChannels(edges, centers, p, alg);
death = channels.typeCode == channels.codes.death & channels.sourceBin == 2;
incoming = channels.typeCode == channels.codes.crossMutation & ...
    channels.sourceBin == 1 & channels.targetBin == 2;
rates = zeros(size(channels.typeCode));
rates(death | incoming) = 4;

% Each first draw kills more than the two original residents. In the last
% case bin 2 would be negative even though the total population is positive.
seeds = [1, 14, 8];
expectedBin2 = [2, 0, -1];
for index = 1:numel(seeds)
    rng(seeds(index), 'twister');
    draw = poissrnd(rates(:));
    finalCounts = counts + (channels.stoichiometry * draw)';
    assert(draw(death) > counts(2) && isequal(finalCounts, [2, expectedBin2(index)]));
    rng(seeds(index), 'twister');
    [accepted, tau, firings, ~, candidate] = tauEstimate(rates, channels, counts, alg, 1);
    if expectedBin2(index) < 0
        % The retry at 0.5 is below 10/a0, so the driver gets Direct fallback.
        assert(~accepted && isnan(tau) && candidate == 0.5 && all(firings == 0));
        assertError(@() tauStep(binned, counts, channels, draw, edges, centers, p), ...
            'tauStep:NegativeFinalCount');
    else
        assert(accepted && tau == 1 && isequal(firings, draw));
        [survivors, updated] = tauStep(binned, counts, channels, firings, edges, centers, p);
        assert(isequal(updated, finalCounts) && isequal(survivors{1}, binned{1}));
        validateTraitState(survivors, updated, edges);
    end
end

% A newborn can also die when there are enough old residents for every death.
firings = zeros(numel(rates), 1);
firings(incoming) = 4;
firings(death) = 1;
rng(4, 'twister');
[survivors, updated] = tauStep(binned, counts, channels, firings, edges, centers, p);
assert(isequal(updated, [2, 5]) && all(ismember(binned{2}, survivors{2})));
validateTraitState(survivors, updated, edges);
end


function traits = terminalFallback(seed, totalTime, p, edges, centers, ...
        binned, counts, channels)
% Independent complete event sequence, discarding any beyond-terminal state.
rng(seed, 'twister');
t = 0;
while t < totalTime
    [~, ~, rates] = computeRates(counts, centers, channels, p);
    if sum(rates) <= 0
        break
    end
    [nextBinned, nextCounts, dt] = directStep( ...
        rates, channels, binned, counts, edges, centers, p);
    if dt > totalTime - t
        break
    end
    t = min(t + dt, totalTime);
    binned = nextBinned; counts = nextCounts;
end
traits = reshape([binned{:}], 1, []);
end


function selectFolder(folder)
addpath(folder, '-begin');
clear computeRates simulateStep updateRatesAfterEvent validateDirectState ...
    simulateDirectRepeat simulateLongDirectRepeat directStep tauEstimate tauStep ...
    simulateRecordedTDTL simulateLongRecordedTDTL initTraitGrid ...
    buildReactionChannels sampleTruncatedMutation validateTraitState
end


function assertError(action, expectedIdentifier)
try
    action();
catch exception
    assert(strcmp(exception.identifier, expectedIdentifier));
    return
end
error('testSimulationTimes:MissingError', 'Expected error was not raised.');
end


function p = modelParameters()
p.r = 1; p.K0 = 300; p.x0 = 0; p.sigmaK = 1; p.sigmaC = 0.4;
p.traitMin = -0.5; p.traitMax = 0.5;
p.mutaProb = 0; p.mutaDeviation = 0.05;
end


function alg = tauParameters()
alg.numTraitBins = 1; alg.mutationCoverageCutoff = 0.99;
alg.epsilon = 0.1; alg.nCritical = 2; alg.leapSwitchFactor = 10;
alg.maxDirectSteps = 5;
end


function channels = simpleChannels()
channels.codes.death = uint8(1); channels.codes.withinBirth = uint8(2);
channels.codes.crossMutation = uint8(3);
channels.stoichiometry = [-1, 1]; channels.typeCode = uint8([1, 2]);
channels.sourceBin = [1, 1]; channels.targetBin = [0, 1];
channels.mutationProbability = [0, 0]; channels.withinMutationMass = 0;
channels.numBins = 1;
end
