function [exactTraits, binCounts] = simulateDirectRepeatReference( ...
        initialTraits, seed, totalTime, modelParams, algParams, binEdges, ...
        debugMode)
%simulateDirectRepeatReference Study driver for one seeded short Direct realization.
%
% algParams.bufferGrowth controls only trait-buffer allocation.  The initial
% buffer reserves that many spare slots, and simulateStepReference uses the same chunk
% size for later expansion.  It has no effect on model propensities.

rng(seed, 'twister');
n = numel(initialTraits);
traitBuffer = zeros(1, n + algParams.bufferGrowth);
traitBuffer(1:n) = reshape(initialTraits, 1, []);
t = 0;

while t < totalTime && n > 0
    activeTraits = traitBuffer(1:n);
    [birthRates, deathRates] = computeRatesReference( ...
        activeTraits, n, modelParams);
    [traitBuffer, n, dt] = simulateStepReference( ...
        n, traitBuffer, birthRates, deathRates, modelParams, algParams, ...
        totalTime - t);
    if dt >= totalTime - t
        t = totalTime;
    else
        t = t + dt;
    end
    if debugMode
        validateDirectState(traitBuffer, n, modelParams);
    end
end

exactTraits = traitBuffer(1:n);
binCounts = uint32(histcounts(exactTraits, binEdges));
if sum(double(binCounts)) ~= n
    error('DirectShort:CountMismatch', ...
        'The common analysis grid did not count every terminal trait.');
end
end
