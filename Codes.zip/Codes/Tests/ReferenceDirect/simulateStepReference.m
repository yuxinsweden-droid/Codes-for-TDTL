function [traitBuffer, n, dt] = simulateStepReference( ...
        n, traitBuffer, birthRates, deathRates, ...
        modelParams, algParams, remainingTime)
%simulateStepReference Execute one optimized exact Direct-method event.
%
% Event selection walks the separate death and birth rate vectors without
% allocating a combined array.  Death uses a last-active-entry swap.
%
% The event-selection mechanism is reusable for individual birth-death
% models.  The Gaussian mutation and trait-boundary rules near the end of
% this function belong to the present model and must be reconsidered when
% event semantics change.
%
% algParams.bufferGrowth controls only memory allocation.  When a
% birth exhausts the trait buffer, this many empty slots are added at once.
% The optional terminal-time guard matches production; the pre-incremental
% event and rate algorithms are otherwise unchanged.

if nargin < 7
    remainingTime = Inf;
end
if remainingTime == 0
    dt = 0;
    return
end

birthRates = reshape(double(birthRates), 1, []);
deathRates = reshape(double(deathRates), 1, []);
if n < 1 || numel(birthRates) ~= n || numel(deathRates) ~= n
    error('simulateStepReference:InvalidState', ...
        'Rates must align with a nonempty active population.');
end
if ~isfield(algParams, 'bufferGrowth') || ...
        ~isscalar(algParams.bufferGrowth) || ...
        algParams.bufferGrowth < 1 || ...
        algParams.bufferGrowth ~= round(algParams.bufferGrowth)
    error('simulateStepReference:InvalidBufferGrowth', ...
        'algParams.bufferGrowth must be a positive integer.');
end

deathTotal = sum(deathRates, 'all');
totalRate = deathTotal + sum(birthRates, 'all');
if totalRate == 0
    dt = remainingTime;
    return
end
if ~isfinite(totalRate) || totalRate <= 0
    error('simulateStepReference:InvalidTotalRate', ...
        'Total event propensity must be finite and positive.');
end

dt = -log(max(rand, realmin)) ./ totalRate;
if dt > remainingTime
    dt = remainingTime;
    return
end
draw = rand .* totalRate;
cumulative = 0;
selected = n;

if draw < deathTotal
    isDeath = true;
    for individual = 1:n
        cumulative = cumulative + deathRates(individual);
        if cumulative > draw
            selected = individual;
            break
        end
    end
else
    isDeath = false;
    draw = draw - deathTotal;
    for individual = 1:n
        cumulative = cumulative + birthRates(individual);
        if cumulative > draw
            selected = individual;
            break
        end
    end
end

parentTrait = traitBuffer(selected);
if isDeath
    traitBuffer(selected) = traitBuffer(n);
    traitBuffer(n) = 0;
    n = n - 1;
    return
end

if rand < modelParams.mutaProb
    offspringTrait = normrnd(parentTrait, modelParams.mutaDeviation);
else
    offspringTrait = parentTrait;
end
if offspringTrait < modelParams.traitMin || ...
        offspringTrait > modelParams.traitMax
    return
end

if numel(traitBuffer) < n + 1
    traitBuffer = [traitBuffer, zeros(1, algParams.bufferGrowth)];
end
traitBuffer(n + 1) = offspringTrait;
n = n + 1;
end
