%RUNALLSMOKETESTS Run every reduced package test without formal data output.
%
% To keep the distributable package compact, the Starter and both Long-time
% tests are local functions below.  All test scripts and fixtures live in
% Tests; production simulations do not depend on this removable folder.

testsRoot = fileparts(mfilename('fullpath'));
codesRoot = fileparts(testsRoot);
addpath(codesRoot);
checkDependencies();
testIncrementalDirect(codesRoot);
testSimulationTimes(codesRoot);

testSimulationEntrypoints(codesRoot);

runStarterSmokeTest(codesRoot);
clear computeRates initPopulation simulateStep updateRatesAfterEvent validateDirectState

runFolderSmokeTest(fullfile(codesRoot, 'Direct method', ...
    'Short time scale'), 'Direct short', fullfile(testsRoot, 'DirectShort'));
clear computeRates simulateStep updateRatesAfterEvent simulateDirectRepeat validateDirectState

runDirectLongSmokeTest(codesRoot);
clear computeRates initPopulation simulateStep updateRatesAfterEvent simulateLongDirectRepeat ...
    validateDirectState

runFolderSmokeTest(fullfile(codesRoot, ...
    'Trait-discretized tau-leaping method', 'Short time scale'), ...
    'TDTL short', fullfile(testsRoot, 'TDTLShort'));
clear buildReactionChannels computeRates directStep initTraitGrid ...
    sampleTruncatedMutation simulateRecordedTDTL tauEstimate tauStep ...
    validateTraitState

runTDTLLongSmokeTest(codesRoot);
clear buildReactionChannels computeRates directStep initPopulation ...
    initTraitGrid sampleTruncatedMutation simulateLongRecordedTDTL ...
    tauEstimate tauStep validateTraitState

runFolderSmokeTest(fullfile(codesRoot, 'Metrics'), 'Metrics', ...
    fullfile(testsRoot, 'Metrics'));
fprintf('\nAll Codes smoke tests passed.\n');


function runFolderSmokeTest(folder, label, testFolder)
% Select production helpers while running the relocated test script.
fprintf('\n=== Smoke test: %s ===\n', label);
addpath(folder, '-begin');
pathGuard = onCleanup(@() rmpath(folder)); %#ok<NASGU>
run(fullfile(testFolder, 'smokeTest.m'));
end


function runStarterSmokeTest(codesRoot)
% Check Starter seeded reproducibility and its one-variable output schema.
fprintf('\n=== Smoke test: Starter ===\n');
folder = fullfile(codesRoot, 'Starter');
addpath(folder, '-begin');
pathGuard = onCleanup(@() rmpath(folder)); %#ok<NASGU>
temporaryRoot = tempname;
mkdir(temporaryRoot);
tempGuard = onCleanup(@() rmdir(temporaryRoot, 's')); %#ok<NASGU>

modelParams = smokeModelParams();
algParams.bufferGrowth = 100;
% Execute the actual Starter script with reduced study settings, rather than
% maintaining a second simulation loop that could miss a production bug.
copyfile(fullfile(folder, '*.m'), temporaryRoot);
source = fileread(fullfile(temporaryRoot, 'main.m'));
source = strrep(source, 'initialPopulation = 500;', 'initialPopulation = 30;');
source = strrep(source, 'totalTime = 10000;', 'totalTime = 0.03;');
source = strrep(source, 'recordInterval = 1;', 'recordInterval = 0.01;');
source = strrep(source, 'progressEvery = 500;', 'progressEvery = 0;');
sourceFile = fopen(fullfile(temporaryRoot, 'main.m'), 'w');
assert(sourceFile ~= -1);
fwrite(sourceFile, source);
fclose(sourceFile);
runStarterFixture(temporaryRoot);
firstData = load(fullfile(temporaryRoot, 'baseTraits.mat'));
first = firstData.baseTraits;
runStarterFixture(temporaryRoot);
secondData = load(fullfile(temporaryRoot, 'baseTraits.mat'));
second = secondData.baseTraits;
assert(isequaln(first, second));
assert(isequal(size(first), [1, 3]));
% Recording must not change the exact path or its final state.
shortFolder = fullfile(codesRoot, 'Direct method', 'Short time scale');
addpath(shortFolder, '-begin');
shortPathGuard = onCleanup(@() rmpath(shortFolder)); %#ok<NASGU>
clear computeRates simulateStep updateRatesAfterEvent simulateDirectRepeat
expectedTerminal = simulateDirectRepeat(repmat(-0.3, 1, 30), ...
    20260618, 0.03, modelParams, algParams, linspace(-0.5, 0.5, 20), true);
assert(isequal(first{end}, expectedTerminal));

baseTraits = first; %#ok<NASGU>
outputFile = fullfile(temporaryRoot, 'baseTraits.mat');
save(outputFile, 'baseTraits');
info = whos('-file', outputFile);
assert(numel(info) == 1 && strcmp(info.name, 'baseTraits'));
% The last record must also exist when the interval does not divide the
% duration, when the horizon is shorter than the interval, or when it is zero.
for horizon = [0.035, 1e-12, 0]
    fixtureSource = strrep(source, 'totalTime = 0.03;', ...
        sprintf('totalTime = %.17g;', horizon));
    sourceFile = fopen(fullfile(temporaryRoot, 'main.m'), 'w');
    assert(sourceFile ~= -1);
    fwrite(sourceFile, fixtureSource);
    fclose(sourceFile);
    runStarterFixture(temporaryRoot);
    saved = load(fullfile(temporaryRoot, 'baseTraits.mat'));
    targets = 0.01:0.01:horizon;
    if isempty(targets) || targets(end) ~= horizon
        targets(end + 1) = horizon;
    end
    assert(numel(saved.baseTraits) == numel(targets));
    expectedTerminal = simulateDirectRepeat(repmat(-0.3, 1, 30), ...
        20260618, horizon, modelParams, algParams, linspace(-0.5, 0.5, 20), true);
    assert(isequal(saved.baseTraits{end}, expectedTerminal));
end
fprintf('Starter smoke test passed.\n');
end


function runStarterFixture(folder)
% Isolate the real script's clear command from test guards and fixtures.
run(fullfile(folder, 'main.m'));
% main.m clears local inputs and defines scriptDir. Remove its path here;
% the calling test owns its temporary directory and production path guards.
rmpath(scriptDir);
end


function runDirectLongSmokeTest(codesRoot)
% Check Direct Long recording times, seed provenance and MAT schema.
fprintf('\n=== Smoke test: Direct long ===\n');
folder = fullfile(codesRoot, 'Direct method', 'Long time scale');
addpath(folder, '-begin');
pathGuard = onCleanup(@() rmpath(folder)); %#ok<NASGU>
temporaryRoot = tempname;
mkdir(temporaryRoot);
tempGuard = onCleanup(@() rmdir(temporaryRoot, 's')); %#ok<NASGU>

modelParams = smokeModelParams();
algParams.bufferGrowth = 100;
traitDistribution.type = 'point';
traitDistribution.value = -0.3;
traitDistribution.numIndividuals = 30;
initialTraits = initPopulation(traitDistribution);
assert(isequal(initialTraits, repmat(-0.3, 1, 30)));
targetTimes = 0:0.01:0.03;

for repeatIndex = 1:2
    seed = 20260618 + repeatIndex;
    outputFile = fullfile(temporaryRoot, ...
        sprintf('repeat_%04d.mat', repeatIndex));
    simulateLongDirectRepeat(initialTraits, seed, 0.03, ...
        targetTimes, modelParams, algParams, outputFile, true);
    info = whos('-file', outputFile);
    names = string({info.name});
    assert(all(ismember(["traitSnapshots", "targetTimes", "seed"], names)));
    assert(~ismember("actualTimes", names));
    data = load(outputFile);
    assert(numel(data.traitSnapshots) == numel(targetTimes));
    assert(isequal(data.targetTimes, targetTimes));
    assert(data.seed == seed);
end
fprintf('Direct long smoke test passed.\n');
end


function runTDTLLongSmokeTest(codesRoot)
% Check TDTL Long crossing semantics, schema, seeds and the 10/a0 switch.
fprintf('\n=== Smoke test: TDTL long ===\n');
folder = fullfile(codesRoot, ...
    'Trait-discretized tau-leaping method', 'Long time scale');
addpath(folder, '-begin');
pathGuard = onCleanup(@() rmpath(folder)); %#ok<NASGU>
temporaryRoot = tempname;
mkdir(temporaryRoot);
tempGuard = onCleanup(@() rmdir(temporaryRoot, 's')); %#ok<NASGU>

modelParams = smokeModelParams();
algParams.numTraitBins = 19;
algParams.mutationCoverageCutoff = 0.99;
algParams.epsilon = 0.1;
algParams.nCritical = 2;
algParams.leapSwitchFactor = 10;
algParams.maxDirectSteps = 5;

traitDistribution.type = 'point';
traitDistribution.value = -0.3;
traitDistribution.numIndividuals = 30;
initialTraits = initPopulation(traitDistribution);
assert(isequal(initialTraits, repmat(-0.3, 1, 30)));
[binEdges, binCenters, initialBinnedTraits, initialCounts] = ...
    initTraitGrid(algParams.numTraitBins, initialTraits, modelParams);
channels = buildReactionChannels( ...
    binEdges, binCenters, modelParams, algParams);

targetTimes = 0:1e-12:3e-12;
seed = 20260619;
outputA = fullfile(temporaryRoot, 'repeat_A.mat');
[snapshotsA, diagnosticsA] = simulateLongRecordedTDTL( ...
    seed, targetTimes(end), targetTimes, modelParams, algParams, ...
    binEdges, binCenters, initialBinnedTraits, initialCounts, channels, ...
    outputA, true);
assert(isequal(snapshotsA{2}, snapshotsA{3}) && ...
    isequal(snapshotsA{3}, snapshotsA{4}));
assert(all(cellfun(@(x) isequal(x, initialTraits), snapshotsA)));
assert(diagnosticsA.tauSteps == 0 && diagnosticsA.directSteps == 0);

info = whos('-file', outputA);
names = sort(string({info.name}));
expectedNames = sort(["binEdges", "seed", "targetTimes", ...
    "traitSnapshots"]);
assert(isequal(names, expectedNames));
assert(~ismember("actualTimes", names));
dataA = load(outputA);
assert(numel(dataA.traitSnapshots) == numel(targetTimes));
assert(isequal(dataA.targetTimes, targetTimes));
assert(dataA.seed == seed);

outputB = fullfile(temporaryRoot, 'repeat_B.mat');
snapshotsB = simulateLongRecordedTDTL( ...
    seed, targetTimes(end), targetTimes, modelParams, algParams, ...
    binEdges, binCenters, initialBinnedTraits, initialCounts, channels, ...
    outputB, true);
assert(isequaln(snapshotsA, snapshotsB));

simpleChannels = makeSimpleTDTLChannels();
rng(1, 'twister');
[useLeap, ~, ~, a0, candidateTau] = tauEstimate( ...
    [1, 1], simpleChannels, 100, algParams);
assert(useLeap && candidateTau > algParams.leapSwitchFactor / a0);
[useLeap, ~, ~, a0, candidateTau] = tauEstimate( ...
    [1, 1], simpleChannels, 2, algParams);
assert(~useLeap && candidateTau <= algParams.leapSwitchFactor / a0);
fprintf('TDTL long smoke test passed.\n');
end


function modelParams = smokeModelParams()
% Return the common reduced-test Dieckmann-Doebeli parameters.
modelParams.r = 1;
modelParams.K0 = 300;
modelParams.x0 = 0;
modelParams.sigmaK = 1;
modelParams.sigmaC = 0.4;
modelParams.traitMin = -0.5;
modelParams.traitMax = 0.5;
modelParams.mutaProb = 0.001;
modelParams.mutaDeviation = 0.05;
end


function channels = makeSimpleTDTLChannels()
% Construct one death and one birth channel for switch-rule testing.
channels.codes.death = uint8(1);
channels.codes.withinBirth = uint8(2);
channels.codes.crossMutation = uint8(3);
channels.stoichiometry = [-1, 1];
channels.typeCode = uint8([1, 2]);
channels.sourceBin = [1, 1];
channels.targetBin = [0, 1];
channels.mutationProbability = [0, 0];
channels.withinMutationMass = 0;
channels.numBins = 1;
end
