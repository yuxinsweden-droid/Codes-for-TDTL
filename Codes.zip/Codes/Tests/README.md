# Removable test folder

All smoke tests, incremental-rate audits and frozen Direct reference routines
are kept here. Production simulations do not depend on this directory.

From MATLAB:

```matlab
addpath('D:\Project 2\Revision2\Codes\Tests');
runAllSmokeTests
```

`testIncrementalDirect` checks births (including self-competition), deaths and
swap removal, extinction, rejected mutants, full rate recomputation, 20,000
successive events, unchanged event/RNG semantics and reduced old/new
trajectories. Existing tests also check repeat seeds, serial/parallel runs,
buffer sizes, long output schemas, TDTL and the error metrics.

`checkDirectPerformance` runs three reduced serial old/new timing comparisons
and a separate profiler check that full rate computation is called only once
per trajectory. It does not produce the formal manuscript's speedup ratios.

`testSimulationTimes` checks terminal event rejection, exact-time recording,
critical events, capped Poisson draws, boundary leaps below the switch
threshold, rejected-leap retries, absorbing states
and recording-grid independence of exact paths. The reduced Starter check
runs a temporary parameter-reduced copy of the real Starter script.

`testSimulationEntrypoints` runs all four real Short/Long mains in temporary
folders, checking `Data2` output, preservation of legacy `Data`, reproducible
seeds, existing MAT fields, zero/tiny durations and a nondividing final grid.

`ReferenceDirect` preserves the pre-optimization rate and event code under
distinct function names, with the same terminal-time guard as production.
It is an oracle for tests, not a production alternative.
Temporary MAT files are cleaned up; no formal `Data` or `Data2` folder is used.

The entire Tests directory can be deleted when these checks are no longer
needed. Rate/state validators remain in production folders because simulation
drivers call them when `debugMode=true`.
