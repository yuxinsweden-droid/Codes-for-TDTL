function testSimulationEntrypoints(codesRoot)
%TESTSIMULATIONENTRYPOINTS Run reduced real mains in disposable folders.
% Verify Data2 output, preservation of legacy Data, seeds, terminal grids,
% zero/tiny durations and the existing MAT schemas without formal runs.
if nargin == 0
    codesRoot = fileparts(fileparts(mfilename('fullpath')));
end
oldPath = path;
pathGuard = onCleanup(@() path(oldPath)); %#ok<NASGU>
temporaryRoot = tempname;
mkdir(temporaryRoot);
tempGuard = onCleanup(@() rmdir(temporaryRoot, 's')); %#ok<NASGU>
methods = {'Direct method', 'Trait-discretized tau-leaping method'};
scales = {'Short time scale', 'Long time scale'};

for methodIndex = 1:2
    for scaleIndex = 1:2
        sourceFolder = fullfile(codesRoot, methods{methodIndex}, scales{scaleIndex});
        fixtureFolder = fullfile(temporaryRoot, sprintf('case_%d_%d', ...
            methodIndex, scaleIndex));
        mkdir(fixtureFolder);
        copyfile(fullfile(sourceFolder, '*.m'), fixtureFolder);
        source = fileread(fullfile(fixtureFolder, 'main.m'));
        source = replaceRequired(source, 'useParallel = true;', 'useParallel = false;');
        source = replaceRequired(source, 'debugMode = false;', 'debugMode = true;');
        if scaleIndex == 1
            source = replaceRequired(source, 'repeatTimes = 100000;', 'repeatTimes = 2;');
            source = replaceRequired(source, 'baseTraitsIndices = 500:500:10000;', ...
                'baseTraitsIndices = 1;');
            timeSetting = 'totalTime = 1;';
            fileName = 'sample_01.mat';
            baseTraits = {repmat(-0.3, 1, 30)}; %#ok<NASGU>
            save(fullfile(fixtureFolder, 'baseTraits.mat'), 'baseTraits');
        else
            source = replaceRequired(source, 'repeatTimes = 400;', 'repeatTimes = 2;');
            source = replaceRequired(source, 'initialPopulation = 500;', ...
                'initialPopulation = 30;');
            source = replaceRequired(source, 'recordInterval = 1;', 'recordInterval = 0.01;');
            timeSetting = 'totalTime = 10000;';
            fileName = 'repeat_0001.mat';
        end

        mkdir(fullfile(fixtureFolder, 'Data'));
        legacySentinel = 137; %#ok<NASGU>
        legacyFile = fullfile(fixtureFolder, 'Data', fileName);
        save(legacyFile, 'legacySentinel');
        for horizon = [0.035, 1e-12, 0]
            fixtureSource = replaceRequired(source, timeSetting, ...
                sprintf('totalTime = %.17g;', horizon));
            writeSource(fullfile(fixtureFolder, 'main.m'), fixtureSource);
            runFixture(fixtureFolder);
            outputFile = fullfile(fixtureFolder, 'Data2', fileName);
            assert(isfile(outputFile));
            first = load(outputFile);
            runFixture(fixtureFolder);
            second = load(outputFile);
            assert(isequaln(first, second));
            legacy = load(legacyFile);
            assert(isequal(fieldnames(legacy), {'legacySentinel'}) && ...
                legacy.legacySentinel == legacySentinel);
            assert(numel(dir(fullfile(fixtureFolder, 'Data', '*.mat'))) == 1);

            if scaleIndex == 1
                expectedFields = {'exactTraits'; 'binCounts'; 'binEdges'; ...
                    'seeds'; 'baseTraitsIndex'};
                assert(isequal(sort(fieldnames(first)), sort(expectedFields)));
                assert(isequal(first.seeds, 20260618 + 100000 + (1:2)'));
                assert(first.baseTraitsIndex == 1);
                for repeatIndex = 1:2
                    assert(isequal(first.binCounts(repeatIndex, :), ...
                        uint32(histcounts(first.exactTraits{repeatIndex}, first.binEdges))));
                    if horizon < 1e-10
                        assert(isequal(first.exactTraits{repeatIndex}, baseTraits{1}));
                    end
                end
            else
                expectedFields = {'traitSnapshots'; 'targetTimes'; 'seed'};
                if methodIndex == 2
                    expectedFields{end + 1} = 'binEdges';
                end
                assert(isequal(sort(fieldnames(first)), sort(expectedFields)));
                targets = 0:0.01:horizon;
                if targets(end) ~= horizon
                    targets(end + 1) = horizon;
                end
                assert(isequal(first.targetTimes, targets));
                assert(numel(first.traitSnapshots) == numel(targets));
                assert(first.seed == 20260619);
                assert(isequal(first.traitSnapshots{1}, repmat(-0.3, 1, 30)));
                if horizon < 1e-10
                    assert(all(cellfun(@(x) isequal(x, repmat(-0.3, 1, 30)), ...
                        first.traitSnapshots)));
                end
            end
            assert(isempty(dir(fullfile(fixtureFolder, 'Data2', '*.part.mat'))));
        end
    end
end
fprintf('All reduced Codes main entrypoints passed (Data2; legacy Data preserved).\n');
end


function source = replaceRequired(source, oldText, newText)
assert(contains(source, oldText));
source = strrep(source, oldText, newText);
end


function writeSource(file, source)
handle = fopen(file, 'w');
assert(handle ~= -1);
fileGuard = onCleanup(@() fclose(handle)); %#ok<NASGU>
fwrite(handle, source);
end


function runFixture(folder)
% Keep the real script's clear command local to this disposable workspace.
clear computeRates simulateStep updateRatesAfterEvent validateDirectState ...
    simulateDirectRepeat simulateLongDirectRepeat directStep tauEstimate ...
    simulateRecordedTDTL simulateLongRecordedTDTL initTraitGrid ...
    initPopulation buildReactionChannels sampleTruncatedMutation ...
    validateTraitState tauStep
run(fullfile(folder, 'main.m'));
rmpath(scriptDir);
end
