%SMOKETEST Validate deterministic seeds and optimized Direct events.

codesRoot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
scriptDir = fullfile(codesRoot, 'Direct method', 'Short time scale');
addpath(scriptDir, '-begin');

modelParams.r = 1;
modelParams.K0 = 300;
modelParams.x0 = 0;
modelParams.sigmaK = 1;
modelParams.sigmaC = 0.4;
modelParams.traitMin = -0.5;
modelParams.traitMax = 0.5;
modelParams.mutaProb = 0.001;
modelParams.mutaDeviation = 0.05;
algParams.bufferGrowth = 100;

initialTraits = repmat(-0.3, 1, 30);
binEdges = linspace(-0.5, 0.5, 20);
seeds = 20260618 + 100000 + (1:4)';
serialTraits = cell(4, 1);
serialCounts = zeros(4, 19, 'uint32');
for repeatIndex = 1:4
    [serialTraits{repeatIndex}, serialCounts(repeatIndex, :)] = ...
        simulateDirectRepeat(initialTraits, seeds(repeatIndex), ...
        0.02, modelParams, algParams, binEdges, true);
end
assert(isequal(size(serialTraits), [4, 1]));
assert(isequal(size(serialCounts), [4, 19]));

% Independent repeat seeds must make parfor scheduling irrelevant.
if ~isempty(ver('parallel')) && license('test', ...
        'Distrib_Computing_Toolbox')
    poolBefore = gcp('nocreate');
    createdPool = isempty(poolBefore);
    if createdPool
        parpool('local', 2);
    end
    parallelTraits = cell(4, 1);
    parallelCounts = zeros(4, 19, 'uint32');
    parfor repeatIndex = 1:4
        [parallelTraits{repeatIndex}, parallelCounts(repeatIndex, :)] = ...
            simulateDirectRepeat(initialTraits, seeds(repeatIndex), ...
            0.02, modelParams, algParams, binEdges, true);
    end
    assert(isequaln(serialTraits, parallelTraits));
    assert(isequal(serialCounts, parallelCounts));
    if createdPool
        delete(gcp('nocreate'));
    end
end

[traitsA, countsA] = simulateDirectRepeat( ...
    initialTraits, 12345, 0.02, modelParams, algParams, binEdges, true);
[traitsB, countsB] = simulateDirectRepeat( ...
    initialTraits, 12345, 0.02, modelParams, algParams, binEdges, true);
assert(isequaln(traitsA, traitsB) && isequal(countsA, countsB));

% Buffer chunk size changes allocation only, not the active stochastic state.
smallBuffer = algParams;
smallBuffer.bufferGrowth = 1;
largeBuffer = algParams;
largeBuffer.bufferGrowth = 137;
[traitsSmall, countsSmall] = simulateDirectRepeat(initialTraits, ...
    24680, 0.02, modelParams, smallBuffer, binEdges, true);
[traitsLarge, countsLarge] = simulateDirectRepeat(initialTraits, ...
    24680, 0.02, modelParams, largeBuffer, binEdges, true);
assert(isequaln(traitsSmall, traitsLarge));
assert(isequal(countsSmall, countsLarge));

% Force an accepted birth when no inactive slot exists.  Both chunk sizes
% must produce the same active state even though allocated lengths differ.
noMutation = modelParams;
noMutation.mutaProb = 0;
fullBuffer = [-0.3, -0.2];
[birthRates, deathRates] = computeRates(fullBuffer, 2, noMutation);
rng(90, 'twister');
[smallAllocation, nSmall, ~, birthsSmall, deathsSmall] = simulateStep( ...
    2, fullBuffer, birthRates, deathRates, noMutation, smallBuffer);
rng(90, 'twister');
[largeAllocation, nLarge, ~, birthsLarge, deathsLarge] = simulateStep( ...
    2, fullBuffer, birthRates, deathRates, noMutation, largeBuffer);
assert(nSmall == 3 && nLarge == 3);
assert(isequal(smallAllocation(1:nSmall), ...
    largeAllocation(1:nLarge)));
assert(numel(smallAllocation) == 3);
assert(numel(largeAllocation) == 2 + largeBuffer.bufferGrowth);
validateDirectState(smallAllocation, nSmall, noMutation, ...
    birthsSmall, deathsSmall);
validateDirectState(largeAllocation, nLarge, noMutation, ...
    birthsLarge, deathsLarge);

% A death uses a last-element swap, so removing individual 1 leaves the old
% last active trait at position 1 without shifting the whole buffer.
buffer = [-0.3, -0.2, 0, 0];
deathOnly = noMutation;
deathOnly.x0 = 1e6; % Gaussian births underflow to zero, leaving exact deaths.
birthRates = zeros(size(buffer));
deathRates = zeros(size(buffer));
[birthRates(1:2), deathRates(1:2)] = computeRates( ...
    buffer(1:2), 2, deathOnly);
rng(2, 'twister');
[buffer, populationAfter, ~, birthRates, deathRates] = simulateStep( ...
    2, buffer, birthRates, deathRates, deathOnly, algParams);
assert(populationAfter == 1 && buffer(1) == -0.2);
validateDirectState(buffer, populationAfter, deathOnly, birthRates, deathRates);
fprintf('Direct short smoke test passed.\n');
