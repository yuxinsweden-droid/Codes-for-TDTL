function result = checkDirectPerformance()
%CHECKDIRECTPERFORMANCE Small serial timing/profile check, not paper results.
% Times identical reduced protocols without file I/O, debugging or a pool.
% Profiling is separate from timing. No TDTL speedup claim is made here.

codesRoot = fileparts(fileparts(mfilename('fullpath')));
oldPath = path;
pathGuard = onCleanup(@() path(oldPath)); %#ok<NASGU>
addpath(fullfile(codesRoot, 'Tests', 'ReferenceDirect'));
addpath(fullfile(codesRoot, 'Direct method', 'Short time scale'), '-begin');
clear computeRates simulateStep updateRatesAfterEvent simulateDirectRepeat
p.r = 1; p.K0 = 300; p.x0 = 0; p.sigmaK = 1; p.sigmaC = 0.4;
p.traitMin = -0.5; p.traitMax = 0.5;
p.mutaProb = 0.001; p.mutaDeviation = 0.05;
alg.bufferGrowth = 100;
x = repmat(-0.3, 1, 500);
edges = linspace(-0.5, 0.5, 20);
finalTime = 0.2;

simulateDirectRepeat(x, 1, 0.01, p, alg, edges, false);
simulateDirectRepeatReference(x, 1, 0.01, p, alg, edges, false);
newSeconds = zeros(1, 3); oldSeconds = zeros(1, 3);
for trial = 1:3
    seed = 1000 + trial;
    started = tic;
    newTraits = simulateDirectRepeat(x, seed, finalTime, p, alg, edges, false);
    newSeconds(trial) = toc(started);
    started = tic;
    oldTraits = simulateDirectRepeatReference(x, seed, finalTime, p, alg, edges, false);
    oldSeconds(trial) = toc(started);
    assert(isequal(newTraits, oldTraits));
end

% Confirm that a production trajectory initializes rates once, rather than
% calling the full-matrix computeRates after each simulated event.
profile clear
profile on
simulateDirectRepeat(x, 1001, finalTime, p, alg, edges, false);
profile off
information = profile('info');
names = {information.FunctionTable.FunctionName};
rateEntry = strcmp(names, 'computeRates');
stepEntry = strcmp(names, 'simulateStep');
assert(nnz(rateEntry) == 1 && information.FunctionTable(rateEntry).NumCalls == 1);
assert(nnz(stepEntry) == 1 && information.FunctionTable(stepEntry).NumCalls > 1);
result = struct('initialPopulation', 500, 'finalTime', finalTime, ...
    'oldSeconds', oldSeconds, 'newSeconds', newSeconds, ...
    'medianOldSeconds', median(oldSeconds), ...
    'medianNewSeconds', median(newSeconds), ...
    'medianRatio', median(oldSeconds)/median(newSeconds), ...
    'fullRateCalls', information.FunctionTable(rateEntry).NumCalls, ...
    'eventCalls', information.FunctionTable(stepEntry).NumCalls);
fprintf('Reduced timing check (500 initial individuals, T=0.2, 3 serial trials):\n');
fprintf('old median %.6fs; incremental median %.6fs; ratio %.2fx.\n', ...
    result.medianOldSeconds, result.medianNewSeconds, result.medianRatio);
fprintf('Separate profile: computeRates %d call; simulateStep %d calls.\n', ...
    result.fullRateCalls, result.eventCalls);
end
