function testIncrementalDirect(codesRoot)
%TESTINCREMENTALDIRECT Audit all Direct copies against complete rate sums.
% No formal data are generated.  The reference event engine is frozen in
% Tests/ReferenceDirect and retains the original event/RNG rules, with the
% same terminal-time guard as production.

if nargin == 0
    codesRoot = fileparts(fileparts(mfilename('fullpath')));
end
oldPath = path;
pathGuard = onCleanup(@() path(oldPath)); 
addpath(fullfile(codesRoot, 'Tests', 'ReferenceDirect'));
folders = {fullfile(codesRoot, 'Direct method', 'Short time scale'), ...
    fullfile(codesRoot, 'Direct method', 'Long time scale'), ...
    fullfile(codesRoot, 'Starter')};

for copyIndex = 1:numel(folders)
    addpath(folders{copyIndex}, '-begin');
    clear computeRates simulateStep updateRatesAfterEvent validateDirectState
    p = modelParameters();
    alg.bufferGrowth = 7;
    fprintf('\n=== Incremental rate audit: %s ===\n', folders{copyIndex});

    % Unequal continuous traits distinguish kernel orientation and indexing.
    x = [-0.31, 0.07, 0.42];
    [x, n, b, d] = initialState(x, p, alg.bufferGrowth);
    validateDirectState(x, n, p, b, d);
    [x, n, b, d] = acceptedBirth(x, n, b, d, 0.19, p);
    validateDirectState(x, n, p, b, d);
    expectedNewborn = p.r / p.K0 * (1 + sum(exp( ...
        -(([-0.31, 0.07, 0.42] - 0.19) .^ 2) / (2*p.sigmaC^2))));
    assert(abs(d(n) - expectedNewborn) < 1e-14);
    % Delete a middle entry, then the last entry, then add an exact clone.
    lastTrait = x(n);
    [x, n, b, d] = acceptedDeath(x, n, b, d, 2, p);
    assert(x(2) == lastTrait);
    validateDirectState(x, n, p, b, d);
    [x, n, b, d] = acceptedDeath(x, n, b, d, n, p);
    validateDirectState(x, n, p, b, d);
    [x, n, b, d] = acceptedBirth(x, n, b, d, x(1), p);
    validateDirectState(x, n, p, b, d);
    while n > 0
        [x, n, b, d] = acceptedDeath(x, n, b, d, 1, p);
        validateDirectState(x, n, p, b, d);
    end
    assert(all(b == 0) && all(d == 0));

    % One-individual mortality exercises extinction inside simulateStep.
    deathOnly = p;
    deathOnly.x0 = 1e6;
    [x, n, b, d] = initialState(0.2, deathOnly, alg.bufferGrowth);
    rng(7, 'twister');
    [x, n, dt, b, d] = simulateStep(n, x, b, d, deathOnly, alg);
    assert(n == 0 && dt > 0);
    validateDirectState(x, n, deathOnly, b, d);

    % A rejected mutant is a null event: positive dt, unchanged state/rates.
    rejected = p;
    rejected.K0 = 1e9;
    rejected.mutaProb = 1;
    rejected.mutaDeviation = 1e6;
    [x, n, b, d] = initialState(0, rejected, alg.bufferGrowth);
    beforeX = x; beforeB = b; beforeD = d;
    rng(90, 'twister');
    [x, afterN, dt, b, d] = simulateStep(n, x, b, d, rejected, alg);
    assert(afterN == n && dt > 0);
    assert(isequal(x, beforeX) && isequal(b, beforeB) && isequal(d, beforeD));

    % Real stochastic events: audit every post-event state against a fresh
    % full competition matrix, including accepted and failed mutant births.
    mixed = p;
    mixed.K0 = 40;
    mixed.mutaProb = 0.6;
    mixed.mutaDeviation = 0.6;
    [x, n, b, d] = initialState(linspace(-0.4, 0.4, 40), mixed, 7);
    rng(400 + copyIndex, 'twister');
    births = 0; deaths = 0; rejectedBirths = 0;
    maximumError = 0;
    for step = 1:2000
        beforeN = n;
        [x, n, dt, b, d] = simulateStep(n, x, b, d, mixed, alg);
        assert(isfinite(dt) && dt > 0);
        births = births + (n > beforeN);
        deaths = deaths + (n < beforeN);
        rejectedBirths = rejectedBirths + (n == beforeN);
        validateDirectState(x, n, mixed, b, d);
        [expectedB, expectedD] = computeRatesReference(x(1:n), n, mixed);
        maximumError = max(maximumError, max(abs( ...
            [b(1:n)-expectedB, d(1:n)-expectedD])));
    end
    assert(births > 0 && deaths > 0 && rejectedBirths > 0);
    fprintf('2000 mixed events: max rate error %.3g; birth/death/null %d/%d/%d.\n', ...
        maximumError, births, deaths, rejectedBirths);
    rmpath(folders{copyIndex});
end

% Longer accumulation test: 20,000 events, full audits every 100 events.
addpath(folders{1}, '-begin');
clear computeRates simulateStep updateRatesAfterEvent validateDirectState
p = modelParameters();
p.K0 = 200;
p.mutaProb = 0.05;
[x, n, b, d] = initialState(linspace(-0.4, 0.4, 200), p, 100);
alg.bufferGrowth = 100;
rng(512, 'twister');
maximumError = 0;
for step = 1:20000
    [x, n, ~, b, d] = simulateStep(n, x, b, d, p, alg);
    if mod(step, 100) == 0
        validateDirectState(x, n, p, b, d);
        [~, expectedD] = computeRatesReference(x(1:n), n, p);
        maximumError = max(maximumError, max(abs(d(1:n)-expectedD)));
    end
end
fprintf('20000-event accumulation audit: max death-rate error %.3g.\n', maximumError);

% Compare the new and old event engines on the SAME pre-event state and RNG.
% This catches changed waiting times, event ordering and mutation semantics.
p = modelParameters();
p.K0 = 50;
p.mutaProb = 0.4;
p.mutaDeviation = 0.2;
for seed = 1:100
    [x, n, b, d] = initialState(linspace(-0.4, 0.4, 50), p, 7);
    rng(seed, 'twister');
    [actualX, actualN, actualDt, actualB, actualD] = ...
        simulateStep(n, x, b, d, p, alg);
    actualRng = rng;
    rng(seed, 'twister');
    [expectedX, expectedN, expectedDt] = simulateStepReference( ...
        n, x, b(1:n), d(1:n), p, alg);
    expectedRng = rng;
    assert(actualN == expectedN && isequal(actualX, expectedX));
    assert(actualDt == expectedDt && isequal(actualRng, expectedRng));
    validateDirectState(actualX, actualN, p, actualB, actualD);
end

% Reduced full trajectories share the corrected terminal-time convention.
% No promise of bitwise path equality over arbitrarily long trajectories:
% floating-point summation order differs between the two implementations.
binEdges = linspace(-0.5, 0.5, 20);
initialTraits = linspace(-0.4, 0.4, 50);
for seed = 1:20
    [newTraits, newCounts] = simulateDirectRepeat( ...
        initialTraits, seed, 0.5, p, alg, binEdges, true);
    [oldTraits, oldCounts] = simulateDirectRepeatReference( ...
        initialTraits, seed, 0.5, p, alg, binEdges, false);
    assert(isequal(newTraits, oldTraits) && isequal(newCounts, oldCounts));
end
[emptyTraits, emptyCounts] = simulateDirectRepeat( ...
    [], 1, 1, p, alg, binEdges, true);
assert(isempty(emptyTraits) && all(emptyCounts == 0));
fprintf('Reference event/RNG and reduced trajectory comparisons passed.\n');
fprintf('All incremental Direct audits passed.\n');
end


function p = modelParameters()
p.r = 1; p.K0 = 300; p.x0 = 0; p.sigmaK = 1; p.sigmaC = 0.4;
p.traitMin = -0.5; p.traitMax = 0.5;
p.mutaProb = 0.001; p.mutaDeviation = 0.05;
end


function [x, n, b, d] = initialState(traits, p, spareSlots)
n = numel(traits);
x = zeros(1, n + spareSlots);
x(1:n) = traits;
b = zeros(size(x)); d = zeros(size(x));
[b(1:n), d(1:n)] = computeRatesReference(traits, n, p);
end


function [x, n, b, d] = acceptedBirth(x, n, b, d, trait, p)
[b, d] = updateRatesAfterEvent(x, n, b, d, p, false, trait, 1);
x(n+1) = trait;
n = n + 1;
end


function [x, n, b, d] = acceptedDeath(x, n, b, d, index, p)
[b, d] = updateRatesAfterEvent(x, n, b, d, p, true, x(index), index);
x(index) = x(n);
x(n) = 0;
n = n - 1;
end
