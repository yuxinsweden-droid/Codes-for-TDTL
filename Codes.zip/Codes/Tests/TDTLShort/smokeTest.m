%SMOKETEST Validate short TDTL channels, branches and reproducibility.

codesRoot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
scriptDir = fullfile(codesRoot, ...
    'Trait-discretized tau-leaping method', 'Short time scale');
addpath(scriptDir, '-begin');

modelParams.r = 1;
modelParams.K0 = 300;
modelParams.x0 = 0;
modelParams.sigmaK = 1;
modelParams.sigmaC = 0.4;
modelParams.traitMin = -0.5;
modelParams.traitMax = 0.5;
modelParams.mutaProb = 0.001;
modelParams.mutaDeviation = 0.05;

algParams.numTraitBins = 19;
algParams.mutationCoverageCutoff = 0.99;
algParams.epsilon = 0.1;
algParams.nCritical = 2;
algParams.leapSwitchFactor = 10;
algParams.maxDirectSteps = 5;

initialTraits = repmat(-0.3, 1, 30);
[binEdges, binCenters, initialBinnedTraits, initialCounts] = ...
    initTraitGrid(algParams.numTraitBins, initialTraits, modelParams);
channels = buildReactionChannels( ...
    binEdges, binCenters, modelParams, algParams);

% Reaction metadata must define exactly one source and propensity per
% stoichiometry column.  All retained mutation channels have positive mass.
numChannels = size(channels.stoichiometry, 2);
assert(numel(channels.typeCode) == numChannels);
assert(numel(channels.sourceBin) == numChannels);
assert(numel(channels.targetBin) == numChannels);
assert(all(channels.mutationProbability( ...
    channels.typeCode == channels.codes.crossMutation) > 0));
[~, ~, rates] = computeRates( ...
    initialCounts, binCenters, channels, modelParams);
assert(numel(rates) == numChannels && all(rates >= 0));

% The mutation sampler must preserve continuous values and bin boundaries.
rng(81, 'twister');
draws = sampleTruncatedMutation(zeros(1, 100), -0.1, 0.1, 0.05);
assert(all(draws >= -0.1 & draws < 0.1));

seeds = 20260618 + 100000 + (1:4)';
serialTraits = cell(4, 1);
serialCounts = zeros(4, algParams.numTraitBins, 'uint32');
for repeatIndex = 1:4
    [serialTraits{repeatIndex}, serialCounts(repeatIndex, :)] = ...
        simulateRecordedTDTL(seeds(repeatIndex), 0.02, ...
        modelParams, algParams, binEdges, binCenters, ...
        initialBinnedTraits, initialCounts, channels, true);
end
assert(isequal(size(serialTraits), [4, 1]));
assert(isequal(size(serialCounts), [4, algParams.numTraitBins]));

% Each repeat resets its own stream, so scheduling cannot affect results.
if ~isempty(ver('parallel')) && license('test', ...
        'Distrib_Computing_Toolbox')
    poolBefore = gcp('nocreate');
    createdPool = isempty(poolBefore);
    if createdPool
        parpool('local', 2);
    end
    parallelTraits = cell(4, 1);
    parallelCounts = zeros(4, algParams.numTraitBins, 'uint32');
    parfor repeatIndex = 1:4
        [parallelTraits{repeatIndex}, parallelCounts(repeatIndex, :)] = ...
            simulateRecordedTDTL(seeds(repeatIndex), 0.02, ...
            modelParams, algParams, binEdges, binCenters, ...
            initialBinnedTraits, initialCounts, channels, true);
    end
    assert(isequaln(serialTraits, parallelTraits));
    assert(isequal(serialCounts, parallelCounts));
    if createdPool
        delete(gcp('nocreate'));
    end
end

[traitsA, countsA] = simulateRecordedTDTL(12345, 0.02, ...
    modelParams, algParams, binEdges, binCenters, ...
    initialBinnedTraits, initialCounts, channels, true);
[traitsB, countsB] = simulateRecordedTDTL(12345, 0.02, ...
    modelParams, algParams, binEdges, binCenters, ...
    initialBinnedTraits, initialCounts, channels, true);
assert(isequaln(traitsA, traitsB) && isequal(countsA, countsB));

% Artificial one-bin channels exercise both sides of candidate tau > 10/a0.
simpleChannels = makeSimpleChannels();
rng(1, 'twister');
[useLeap, tau, firings, a0, candidateTau] = tauEstimate( ...
    [1, 1], simpleChannels, 100, algParams);
assert(useLeap && candidateTau > algParams.leapSwitchFactor / a0);
assert(tau > 0 && all(firings >= 0) && all(firings == round(firings)));
[useLeap, ~, firings, a0, candidateTau] = tauEstimate( ...
    [1, 1], simpleChannels, 2, algParams);
assert(~useLeap && candidateTau <= algParams.leapSwitchFactor / a0);
assert(all(firings == 0));

fprintf('TDTL short smoke test passed.\n');


function channels = makeSimpleChannels()
channels.codes.death = uint8(1);
channels.codes.withinBirth = uint8(2);
channels.codes.crossMutation = uint8(3);
channels.stoichiometry = [-1, 1];
channels.typeCode = uint8([1, 2]);
channels.sourceBin = [1, 1];
channels.targetBin = [0, 1];
channels.mutationProbability = [0, 0];
channels.withinMutationMass = 0;
channels.numBins = 1;
end
