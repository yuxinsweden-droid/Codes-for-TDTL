%SMOKETEST Verify W1 and MHE formulas and metric-only MAT outputs.

codesRoot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
scriptDir = fullfile(codesRoot, 'Metrics');
addpath(scriptDir, '-begin');
temporaryRoot = tempname;
mkdir(temporaryRoot);
cleanup = onCleanup(@() rmdir(temporaryRoot, 's'));

%% W1 short-time tests
directShort = fullfile(temporaryRoot, 'directShort');
tdtlShort = fullfile(temporaryRoot, 'tdtlShort');
mkdir(directShort);
mkdir(tdtlShort);
shortEdges = [-1, 0, 1, 2];
shortSeeds = [101; 102];

% Identical mean ECDFs give zero.
exactTraits = {[0; 1], [0.25; 0.75]};
saveShortFile(fullfile(directShort, 'sample_01.mat'), ...
    exactTraits, shortEdges, shortSeeds, 10);
saveShortFile(fullfile(tdtlShort, 'sample_01.mat'), ...
    exactTraits, shortEdges, shortSeeds, 10);

% Translating every trait by 0.1 gives W1=0.1.
exactTraits = {[0; 1], [0.25; 0.75]};
saveShortFile(fullfile(directShort, 'sample_02.mat'), ...
    exactTraits, shortEdges, shortSeeds, 20);
exactTraits = cellfun(@(x) x + 0.1, exactTraits, ...
    'UniformOutput', false);
saveShortFile(fullfile(tdtlShort, 'sample_02.mat'), ...
    exactTraits, shortEdges, shortSeeds, 20);

% A one-individual and a three-individual repeat each receive mass 1/2.
exactTraits = {0, [1, 1, 1]};
saveShortFile(fullfile(directShort, 'sample_03.mat'), ...
    exactTraits, shortEdges, shortSeeds, 30);
exactTraits = {[0.5, 0.5], [0.5, 0.5]};
saveShortFile(fullfile(tdtlShort, 'sample_03.mat'), ...
    exactTraits, shortEdges, shortSeeds, 30);

shortOutput = fullfile(temporaryRoot, 'W1_short.mat');
shortW1 = calculateW1("short", directShort, tdtlShort, ...
    shortOutput, 3, 2, []);
assert(abs(shortW1(1)) < 1e-12);
assert(abs(shortW1(2) - 0.1) < 1e-12);
assert(abs(shortW1(3) - 0.5) < 1e-12);
assertOnlyMetric(shortOutput, 'W1');

% Existing W1 must be overwritten when complete input data change.
exactTraits = {[0.2; 1.2], [0.45; 0.95]};
saveShortFile(fullfile(tdtlShort, 'sample_02.mat'), ...
    exactTraits, shortEdges, shortSeeds, 20);
shortW1 = calculateW1("short", directShort, tdtlShort, ...
    shortOutput, 3, 2, []);
assert(abs(shortW1(2) - 0.2) < 1e-12);

%% W1 long-time block-reading test
directLong = fullfile(temporaryRoot, 'directLong');
tdtlLong = fullfile(temporaryRoot, 'tdtlLong');
mkdir(directLong);
mkdir(tdtlLong);
targetTimes = 0:2; %#ok<NASGU>
binEdges = [-0.5, 0, 0.5]; %#ok<NASGU>
for repeatIndex = 1:2
    seed = 100 + repeatIndex; %#ok<NASGU>
    traitSnapshots = {[0, 1], [0.25, 0.75], [0.5, 1]}; %#ok<NASGU>
    save(fullfile(directLong, sprintf('repeat_%04d.mat', repeatIndex)), ...
        'traitSnapshots', 'targetTimes', 'seed', '-v7.3');
    traitSnapshots = cellfun(@(x) x + 0.1, traitSnapshots, ...
        'UniformOutput', false); %#ok<NASGU>
    save(fullfile(tdtlLong, sprintf('repeat_%04d.mat', repeatIndex)), ...
        'traitSnapshots', 'targetTimes', 'seed', 'binEdges', '-v7.3');
end
longOutput = fullfile(temporaryRoot, 'W1_long.mat');
longW1 = calculateW1("long", directLong, tdtlLong, ...
    longOutput, 2, [], 2);
assert(all(abs(longW1 - 0.1) < 1e-12));
assertOnlyMetric(longOutput, 'W1');

%% MHE identity and complete-separation tests
directMHE = fullfile(temporaryRoot, 'directMHE');
tdtlMHE = fullfile(temporaryRoot, 'tdtlMHE');
mkdir(directMHE);
mkdir(tdtlMHE);
binEdges = [-0.5, 0, 0.5]; %#ok<NASGU>

seeds = (1:10)';
exactTraits = repmat({[-0.25, 0.25]}, 10, 1);
saveShortFile(fullfile(directMHE, 'sample_01.mat'), ...
    exactTraits, binEdges, seeds, 10);
saveShortFile(fullfile(tdtlMHE, 'sample_01.mat'), ...
    exactTraits, binEdges, seeds, 10);

exactTraits = repmat({-0.25}, 10, 1);
saveShortFile(fullfile(directMHE, 'sample_02.mat'), ...
    exactTraits, binEdges, seeds, 20);
exactTraits = repmat({repmat(-0.25, 1, 10)}, 10, 1);
saveShortFile(fullfile(tdtlMHE, 'sample_02.mat'), ...
    exactTraits, binEdges, seeds, 20);

mheOutput = fullfile(temporaryRoot, 'MHE_short.mat');
MHE = calculateMHE(directMHE, tdtlMHE, mheOutput, 2, 10, 2);
assert(abs(MHE(1)) < 1e-12);
assert(abs(MHE(2) - 2) < 1e-12);
assert(all(MHE >= 0 & MHE <= 2));
assertOnlyMetric(mheOutput, 'MHE');

% Existing MHE must also be replaced rather than resumed.
exactTraits = repmat({repmat([-0.25, 0.25], 1, 10)}, 10, 1);
saveShortFile(fullfile(tdtlMHE, 'sample_01.mat'), ...
    exactTraits, binEdges, seeds, 10);
MHE = calculateMHE(directMHE, tdtlMHE, mheOutput, 2, 10, 2);
assert(abs(MHE(1) - 2) < 1e-12);
assertOnlyMetric(mheOutput, 'MHE');
fprintf('Metrics smoke test passed.\n');


function assertOnlyMetric(path, expectedName)
info = whos('-file', path);
assert(numel(info) == 1 && strcmp(info.name, expectedName));
end


function saveShortFile(path, exactTraits, binEdges, seeds, baseTraitsIndex)
numRepeats = numel(exactTraits);
numBins = numel(binEdges) - 1;
binCounts = zeros(numRepeats, numBins, 'uint32');
for repeatIndex = 1:numRepeats
    binCounts(repeatIndex, :) = uint32( ...
        histcounts(exactTraits{repeatIndex}, binEdges));
end
exactTraits = exactTraits(:);
seeds = seeds(:);
save(path, 'exactTraits', 'binCounts', 'binEdges', 'seeds', ...
    'baseTraitsIndex', '-v7.3');
end
