# Debugging process and guidelines

## 1. Check the environment

Run `checkDependencies`.  Resolve missing Statistics Toolbox functions before
running any simulation.  Parallel Toolbox warnings can be ignored when a
serial run is acceptable.

## 2. Run the smoke tests

Add `Tests` to the MATLAB path and run `runAllSmokeTests`. All checks and
reference routines are collected under that removable folder. The runner
checks incremental Direct rates, Starter and Long recording, and Direct Short,
TDTL Short and Metrics. Tests use temporary directories and reduced settings;
they do not touch formal `Data` or `Data2` folders. Reduced real-main checks
verify that output goes to `Data2` and legacy `Data` remains intact.
A failed test should be fixed before
increasing repeat counts or final time.

The Metrics smoke test checks both formulas, complete-data validation,
replacement of old metric files and the one-variable output schema.

## 3. Reproduce one repeat

In a temporary copy of the relevant `main.m`, set `useParallel = false`,
reduce `repeatTimes` to one, and set `debugMode = true`.  All debugging values
are visible near the beginning of that file; there is no separate
configuration wrapper.  Each repeat resets the Twister stream from its
documented seed.  Re-running the same repeat must reproduce the exact terminal
traits or snapshot cells.

## 4. Diagnose the direct method

- `algParams.bufferGrowth` is an implementation setting, not a biological
  model parameter.  It specifies how many trait slots are appended when the
  active population exhausts the current buffer.  Changing it affects
  allocation frequency and memory overhead, but not propensities or model
  laws. Trait, birth-rate and death-rate buffers grow together; only entries
  `1:n` are active.
- Confirm `n` equals the number of active entries in the preallocated buffer.
- Death subtracts the deceased individual's competition contribution before
  swapping the selected trait and both rates with active entry `n`. Inactive
  buffer values must never be passed to `computeRates`.
- A rejected out-of-range mutant is a failed birth, not a clipped trait.
- Retain the rate outputs from `simulateStep` for the next event; do not
  rebuild rates in the simulation loop. `computeRates` initializes each
  trajectory; `updateRatesAfterEvent` maintains its exact model propensities.
- Pass `totalTime-t` as the remaining interval. An event beyond that interval
  leaves traits and cached rates unchanged; `eventOccurred` is false. An
  out-of-domain mutant birth within the interval is still an occurred event.
- `validateDirectState` detects invalid traits, rate-buffer misalignment,
  nonzero inactive rates and disagreement with full rate recomputation.
  Its full audit is O(n^2), so use `debugMode=false` when measuring speed.

## 5. Diagnose TDTL

- `a0` is the sum of all reaction propensities.
- Select a leap only when the untruncated candidate satisfies
  `candidateTau > 10/a0`. A feasible boundary cap below that threshold still
  uses the selected leap.
- Reaction channels with source population `1` are critical because
  `nCritical = 2`; channels with source population at least 2 are
  noncritical.
- An infeasible leap is retried from half the capped candidate. Once this
  reduced candidate is no longer above `10/a0`, use direct-method fallback.
- Cap the selected candidate at the terminal time (Short) or next
  observation (Long) before critical and Poisson draws. Never shorten a tau
  after its firings were sampled. `candidateTau` reports the selection
  estimate; `tau` reports the accepted interval.
- With `debugMode = true`, `validateTraitState` checks nonnegative integer
  counts and verifies that every retained continuous trait lies in its
  assigned bin.
- `simulateRecordedTDTL` returns branch counts in its third output, and
  `simulateLongRecordedTDTL` returns them in its second output.  Inspect the
  `tauSteps`, `directSteps` and `tauFallbacks` fields for one reduced repeat.

## 6. Interpret long-time snapshots

Both methods use `targetTimes = 0:1:10000`. Direct and Starter save the
pre-event state at targets strictly before the next event, retaining that
event's sampled waiting time. A target exactly at an event receives the
post-event state. TDTL caps tau at the next target before drawing firings;
exact fallback uses the Direct recording convention. A later event never
changes an earlier snapshot, and no event beyond the final time is executed.
Unchanged adjacent snapshots are valid. `actualTimes` is not saved.

The Direct path is independent of the recording grid. TDTL's grid constrains
its leaps and can change accuracy and runtime; use identical targetTimes in
comparisons and regenerate old long-time outputs after this correction.

## 7. Diagnose W1 and MHE

Use the only metric functions in `Metrics` for formal analysis.  Do not add
all of `Codes` recursively to the MATLAB path because simulation folders have
repeated helper names such as `computeRates.m`.

- W1 requires nonempty continuous-trait cells.  It gives every nonempty
  replicate total mass `1/R`, then integrates the absolute difference between
  the two merged empirical CDFs.
- MHE first uses the common 19-bin trait grid, constructs count histograms
  across repeats, takes their L1 difference for each trait bin, and reports the
  maximum.  A valid result lies in `[0,2]`.
- Inspect an output with `whos('-file', path)`.  W1 files must contain only
  `W1`; the MHE file must contain only `MHE`.
- If any required simulation file, seed, initial-state index, grid or target
  time is missing or mismatched, the metric function stops before calculating
  its first value.  Existing metrics are not used as checkpoints.

## 8. Recover from interrupted formal runs

Short-time programs save one file per initial state, and long-time programs
save one file per repeat, all under `Data2`. Legacy `Data` is preserved.
Running a `main.m` again recomputes its requested
simulations and replaces files with matching names.  Temporary `.part.mat`
files are not formal results and may be removed after confirming that no
MATLAB worker is writing them.
