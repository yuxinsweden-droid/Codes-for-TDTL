function MHE = calculateMHE(directFolder, tdtlFolder, outputFile, ...
        numSamples, expectedRepeats, numHistogramBins)
%CALCULATEMHE Compute the short-time maximum histogram error (MHE).
%
% FORMAL RUN
%   MHE = calculateMHE() verifies all 20 paired Direct/TDTL sample files
%   before calculating any error.  It then recomputes the complete MHE
%   vector and saves MHE_short.mat.
%
% SELECTIVE RUN OR TEST
%   MHE = calculateMHE(directFolder,tdtlFolder,outputFile,...
%       numSamples,expectedRepeats,numHistogramBins)
%
% For each trait bin, replicate population counts define two normalized
% histograms.  MHE is the largest L1 histogram difference over trait bins.
% Existing metric values are never resumed or reused.

if nargin == 0
    scriptDir = fileparts(mfilename('fullpath'));
    codesRoot = findCodesRoot(scriptDir);
    directFolder = fullfile(codesRoot, ...
        'Direct method', 'Short time scale', 'Data2');
    tdtlFolder = fullfile(codesRoot, ...
        'Trait-discretized tau-leaping method', 'Short time scale', 'Data2');
    outputFile = fullfile(scriptDir, 'MHE_short.mat');
    numSamples = 20;
    expectedRepeats = 100000;
    numHistogramBins = 18;
    expectedBaseIndices = 500:500:10000;
    formalBaseSeed = 20260618;
elseif nargin == 6
    expectedBaseIndices = [];
    formalBaseSeed = [];
else
    error('MHE:InvalidInputCount', ...
        'Use calculateMHE() or provide all six selective-run inputs.');
end

if ~isscalar(numSamples) || numSamples < 1 || ...
        numSamples ~= round(numSamples) || ...
        ~isscalar(expectedRepeats) || expectedRepeats < 1 || ...
        expectedRepeats ~= round(expectedRepeats) || ...
        ~isscalar(numHistogramBins) || numHistogramBins < 1 || ...
        numHistogramBins ~= round(numHistogramBins)
    error('MHE:InvalidSettings', ...
        'Samples, repeats and histogram bins must be positive integers.');
end

data = validateShortDataset(directFolder, tdtlFolder, numSamples, ...
    expectedRepeats, expectedBaseIndices, formalBaseSeed);
discardOldMetric(outputFile);
MHE = nan(numSamples, 1);

for sampleIndex = 1:numSamples
    direct = load(data.directFiles(sampleIndex), ...
        'exactTraits', 'binCounts', 'binEdges');
    tdtl = load(data.tdtlFiles(sampleIndex), 'binCounts', 'binEdges');

    % Independently remap Direct continuous traits to the shared grid.  This
    % confirms that saved Direct binCounts were not produced on another grid.
    numTraitBins = numel(direct.binEdges) - 1;
    directCounts = zeros(expectedRepeats, numTraitBins, 'uint32');
    for repeatIndex = 1:expectedRepeats
        traits = double(direct.exactTraits{repeatIndex}(:));
        if any(~isfinite(traits))
            error('MHE:InvalidDirectTrait', ...
                'A Direct repeat contains a nonfinite trait.');
        end
        directCounts(repeatIndex, :) = uint32( ...
            histcounts(traits, direct.binEdges));
        if sum(double(directCounts(repeatIndex, :))) ~= numel(traits)
            error('MHE:UncountedTrait', ...
                'The common grid did not count every Direct trait.');
        end
    end
    if ~isequal(directCounts, uint32(direct.binCounts))
        error('MHE:DirectCountMismatch', ...
            'Stored Direct counts do not match remapped exact traits.');
    end

    countErrors = zeros(1, numTraitBins);
    tdtlCounts = double(tdtl.binCounts);
    for traitBin = 1:numTraitBins
        directValues = double(directCounts(:, traitBin));
        tdtlValues = tdtlCounts(:, traitBin);
        if any(~isfinite(tdtlValues)) || any(tdtlValues < 0) || ...
                any(tdtlValues ~= round(tdtlValues))
            error('MHE:InvalidCounts', ...
                'TDTL contains invalid population counts.');
        end
        lowerCount = min([directValues; tdtlValues]);
        upperCount = max([directValues; tdtlValues]);
        if upperCount == lowerCount
            countErrors(traitBin) = 0;
            continue
        end
        countEdges = linspace(lowerCount, upperCount, ...
            numHistogramBins + 1);
        directHistogram = histcounts(directValues, countEdges) ./ ...
            expectedRepeats;
        tdtlHistogram = histcounts(tdtlValues, countEdges) ./ ...
            expectedRepeats;
        countErrors(traitBin) = sum(abs( ...
            directHistogram - tdtlHistogram));
    end

    MHE(sampleIndex) = max(countErrors);
    if ~isfinite(MHE(sampleIndex)) || MHE(sampleIndex) < -1e-12 || ...
            MHE(sampleIndex) > 2 + 1e-12
        error('MHE:InvalidResult', 'Computed MHE lies outside [0,2].');
    end
    MHE(sampleIndex) = min(max(MHE(sampleIndex), 0), 2);
    fprintf('Short MHE sample %d/%d = %.12g\n', ...
        sampleIndex, numSamples, MHE(sampleIndex));
end

saveMHE(outputFile, MHE);
end


function data = validateShortDataset(directFolder, tdtlFolder, ...
        numSamples, expectedRepeats, expectedBaseIndices, formalBaseSeed)
% Require every paired short file before the first MHE value is calculated.
requireFolder(directFolder, 'Direct');
requireFolder(tdtlFolder, 'TDTL');
if ~isempty(expectedBaseIndices) && ...
        numel(expectedBaseIndices) ~= numSamples
    error('MHE:InternalFormalSettings', ...
        'Formal base-trait indices do not match numSamples.');
end

data.directFiles = strings(numSamples, 1);
data.tdtlFiles = strings(numSamples, 1);
referenceEdges = [];
for sampleIndex = 1:numSamples
    data.directFiles(sampleIndex) = fullfile(directFolder, ...
        sprintf('sample_%02d.mat', sampleIndex));
    data.tdtlFiles(sampleIndex) = fullfile(tdtlFolder, ...
        sprintf('sample_%02d.mat', sampleIndex));
    directMeta = inspectShortFile( ...
        data.directFiles(sampleIndex), expectedRepeats);
    tdtlMeta = inspectShortFile( ...
        data.tdtlFiles(sampleIndex), expectedRepeats);

    if ~isequal(directMeta.seeds, tdtlMeta.seeds)
        error('MHE:SeedMismatch', ...
            'Direct and TDTL seeds differ for sample %d.', sampleIndex);
    end
    if directMeta.baseTraitsIndex ~= tdtlMeta.baseTraitsIndex
        error('MHE:InitialStateMismatch', ...
            'Direct and TDTL initial-state indices differ for sample %d.', ...
            sampleIndex);
    end
    if ~isequal(directMeta.binEdges, tdtlMeta.binEdges)
        error('MHE:GridMismatch', ...
            'Direct and TDTL trait grids differ for sample %d.', sampleIndex);
    end
    if isempty(referenceEdges)
        referenceEdges = directMeta.binEdges;
    elseif ~isequal(referenceEdges, directMeta.binEdges)
        error('MHE:GridMismatch', ...
            'The short samples do not share one trait grid.');
    end

    if ~isempty(expectedBaseIndices) && ...
            directMeta.baseTraitsIndex ~= expectedBaseIndices(sampleIndex)
        error('MHE:FormalInitialStateMismatch', ...
            'Sample %d has the wrong baseTraitsIndex.', sampleIndex);
    end
    if ~isempty(formalBaseSeed)
        expectedSeeds = formalBaseSeed + sampleIndex * 100000 + ...
            (1:expectedRepeats)';
        if ~isequal(directMeta.seeds, double(expectedSeeds))
            error('MHE:FormalSeedMismatch', ...
                'Sample %d has the wrong formal seeds.', sampleIndex);
        end
    end
end
fprintf('Validated all %d paired short-time samples for MHE.\n', numSamples);
end


function meta = inspectShortFile(path, expectedRepeats)
% Check complete simulation schema without loading the large trait cells.
if ~isfile(path)
    error('MHE:MissingInput', 'Missing short simulation file: %s', path);
end
info = whos('-file', path);
names = string({info.name});
required = ["exactTraits", "binCounts", "binEdges", "seeds", ...
    "baseTraitsIndex"];
if ~all(ismember(required, names))
    error('MHE:InvalidSchema', ...
        'A required variable is missing from %s.', path);
end
traitInfo = info(names == "exactTraits");
countInfo = info(names == "binCounts");
if numel(traitInfo) ~= 1 || ~strcmp(traitInfo.class, 'cell') || ...
        prod(double(traitInfo.size)) ~= expectedRepeats || ...
        numel(countInfo) ~= 1 || ~strcmp(countInfo.class, 'uint32')
    error('MHE:InvalidSchema', ...
        'Trait or count storage has the wrong type in %s.', path);
end

loaded = load(path, 'binEdges', 'seeds', 'baseTraitsIndex');
meta.binEdges = double(loaded.binEdges(:).');
meta.seeds = double(loaded.seeds(:));
meta.baseTraitsIndex = double(loaded.baseTraitsIndex);
numBins = numel(meta.binEdges) - 1;
if numBins < 1 || any(~isfinite(meta.binEdges)) || ...
        any(diff(meta.binEdges) <= 0) || ...
        ~isequal(double(countInfo.size), [expectedRepeats, numBins])
    error('MHE:InvalidDimensions', ...
        'Trait grid or binCounts dimensions are invalid in %s.', path);
end
if numel(meta.seeds) ~= expectedRepeats || ...
        any(~isfinite(meta.seeds)) || any(meta.seeds ~= round(meta.seeds)) || ...
        numel(unique(meta.seeds)) ~= expectedRepeats
    error('MHE:InvalidSeeds', 'Seeds are invalid or repeated in %s.', path);
end
if ~isscalar(meta.baseTraitsIndex) || ...
        ~isfinite(meta.baseTraitsIndex) || ...
        meta.baseTraitsIndex ~= round(meta.baseTraitsIndex)
    error('MHE:InvalidInitialState', ...
        'baseTraitsIndex is invalid in %s.', path);
end
end


function discardOldMetric(outputFile)
% Ensure no value from an earlier dataset can be returned by this call.
if isfile(outputFile)
    delete(outputFile);
end
partFile = string(outputFile) + ".part.mat";
if isfile(partFile)
    delete(partFile);
end
end


function saveMHE(outputFile, MHE)
% Save only MHE after the complete vector has been calculated.
partFile = string(outputFile) + ".part.mat";
save(partFile, 'MHE', '-v7.3');
movefile(partFile, outputFile, 'f');
end


function requireFolder(path, methodName)
if ~isfolder(path)
    error('MHE:MissingDataFolder', ...
        'Missing %s data folder: %s', methodName, path);
end
end


function codesRoot = findCodesRoot(startDirectory)
% Walk upward to locate the enclosing Codes tree.
codesRoot = startDirectory;
while true
    if isfile(fullfile(codesRoot, 'checkDependencies.m')) && ...
            isfolder(fullfile(codesRoot, 'Direct method')) && ...
            isfolder(fullfile(codesRoot, ...
            'Trait-discretized tau-leaping method'))
        return
    end
    parent = fileparts(codesRoot);
    if strcmp(parent, codesRoot)
        error('MHE:CodesRootNotFound', ...
            'Could not locate the enclosing Codes directory.');
    end
    codesRoot = parent;
end
end
