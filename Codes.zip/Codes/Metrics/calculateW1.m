function [W1Short, W1Long] = calculateW1(timeScale, directFolder, ...
        tdtlFolder, outputFile, numItems, expectedRepeats, blockSize)
%CALCULATEW1 Compute replicate-weighted continuous-trait Wasserstein distance.
%
% FORMAL RUN
%   From Codes/Metrics, [W1Short,W1Long] = calculateW1() first verifies that
%   every formal Direct and TDTL output is present and correctly paired.  It
%   then computes both analyses from the beginning.  A copy in a Short or
%   Long method directory validates and computes only that time scale.
%
% SELECTIVE RUN OR TEST
%   W1 = calculateW1(timeScale,directFolder,tdtlFolder,outputFile,...
%       numItems,expectedRepeats,blockSize) uses caller-supplied settings.
%
% OUTPUT
%   W1Short - one value per short-time initial state.
%   W1Long  - one value per long-time target time.
%
% No existing metric is resumed.  All required simulation data are checked
% before calculation starts, and the result file is written only after the
% requested W1 vector has been completed.  Each replicate receives total
% probability 1/R, independent of its population size.

if nargin == 0
    scriptDir = fileparts(mfilename('fullpath'));
    codesRoot = findCodesRoot(scriptDir);
    [~, localFolderName] = fileparts(scriptDir);

    directShortFolder = fullfile(codesRoot, ...
        'Direct method', 'Short time scale', 'Data2');
    tdtlShortFolder = fullfile(codesRoot, ...
        'Trait-discretized tau-leaping method', 'Short time scale', 'Data2');
    directLongFolder = fullfile(codesRoot, ...
        'Direct method', 'Long time scale', 'Data2');
    tdtlLongFolder = fullfile(codesRoot, ...
        'Trait-discretized tau-leaping method', 'Long time scale', 'Data2');

    if strcmp(localFolderName, 'Short time scale')
        shortData = validateShortDataset(directShortFolder, ...
            tdtlShortFolder, 20, 100000, 500:500:10000, 20260618);
        W1Short = computeShortW1(shortData, ...
            fullfile(scriptDir, 'W1_short.mat'), 100000);
        W1Long = [];
        return
    end

    if strcmp(localFolderName, 'Long time scale')
        longData = validateLongDataset(directLongFolder, ...
            tdtlLongFolder, 400, 0:1:10000, 20260618);
        W1Short = [];
        W1Long = computeLongW1(longData, ...
            fullfile(scriptDir, 'W1_long.mat'), 10);
        return
    end

    % The canonical Metrics copy requires both complete datasets before it
    % starts either calculation.
    shortData = validateShortDataset(directShortFolder, ...
        tdtlShortFolder, 20, 100000, 500:500:10000, 20260618);
    longData = validateLongDataset(directLongFolder, ...
        tdtlLongFolder, 400, 0:1:10000, 20260618);
    W1Short = computeShortW1(shortData, ...
        fullfile(scriptDir, 'W1_short.mat'), 100000);
    W1Long = computeLongW1(longData, ...
        fullfile(scriptDir, 'W1_long.mat'), 10);
    return
elseif nargin ~= 7
    error('W1:InvalidInputCount', ...
        'Use calculateW1() or provide all seven selective-run inputs.');
end

timeScale = lower(string(timeScale));
if ~isscalar(timeScale) || ~ismember(timeScale, ["short", "long"])
    error('W1:InvalidTimeScale', 'timeScale must be "short" or "long".');
end
if ~isscalar(numItems) || numItems < 1 || numItems ~= round(numItems)
    error('W1:InvalidItemCount', 'numItems must be a positive integer.');
end

if timeScale == "short"
    if ~isscalar(expectedRepeats) || expectedRepeats < 1 || ...
            expectedRepeats ~= round(expectedRepeats)
        error('W1:InvalidRepeatCount', ...
            'Short expectedRepeats must be a positive integer.');
    end
    shortData = validateShortDataset(directFolder, tdtlFolder, ...
        numItems, expectedRepeats, [], []);
    W1Short = computeShortW1( ...
        shortData, outputFile, expectedRepeats);
    W1Long = [];
else
    if ~isscalar(blockSize) || blockSize < 1 || ...
            blockSize ~= round(blockSize)
        error('W1:InvalidBlockSize', ...
            'Long blockSize must be a positive integer.');
    end
    longData = validateLongDataset( ...
        directFolder, tdtlFolder, numItems, [], []);
    W1Short = computeLongW1(longData, outputFile, blockSize);
    W1Long = [];
end
end


function data = validateShortDataset(directFolder, tdtlFolder, ...
        numSamples, expectedRepeats, expectedBaseIndices, formalBaseSeed)
% Verify the complete short dataset before any W1 value is calculated.
requireFolder(directFolder, 'Direct');
requireFolder(tdtlFolder, 'TDTL');
if ~isempty(expectedBaseIndices) && ...
        numel(expectedBaseIndices) ~= numSamples
    error('W1:InternalFormalSettings', ...
        'Formal base-trait indices do not match numSamples.');
end

data.directFiles = strings(numSamples, 1);
data.tdtlFiles = strings(numSamples, 1);
referenceEdges = [];
for sampleIndex = 1:numSamples
    data.directFiles(sampleIndex) = fullfile(directFolder, ...
        sprintf('sample_%02d.mat', sampleIndex));
    data.tdtlFiles(sampleIndex) = fullfile(tdtlFolder, ...
        sprintf('sample_%02d.mat', sampleIndex));
    directMeta = inspectShortFile( ...
        data.directFiles(sampleIndex), expectedRepeats);
    tdtlMeta = inspectShortFile( ...
        data.tdtlFiles(sampleIndex), expectedRepeats);

    if ~isequal(directMeta.seeds, tdtlMeta.seeds)
        error('W1:SeedMismatch', ...
            'Direct and TDTL seeds differ for short sample %d.', sampleIndex);
    end
    if directMeta.baseTraitsIndex ~= tdtlMeta.baseTraitsIndex
        error('W1:InitialStateMismatch', ...
            'Direct and TDTL initial-state indices differ for sample %d.', ...
            sampleIndex);
    end
    if ~isequal(directMeta.binEdges, tdtlMeta.binEdges)
        error('W1:GridMismatch', ...
            'Direct and TDTL trait grids differ for sample %d.', sampleIndex);
    end
    if isempty(referenceEdges)
        referenceEdges = directMeta.binEdges;
    elseif ~isequal(referenceEdges, directMeta.binEdges)
        error('W1:GridMismatch', ...
            'The short samples do not share one trait grid.');
    end

    if ~isempty(expectedBaseIndices) && ...
            directMeta.baseTraitsIndex ~= expectedBaseIndices(sampleIndex)
        error('W1:FormalInitialStateMismatch', ...
            'Short sample %d has the wrong baseTraitsIndex.', sampleIndex);
    end
    if ~isempty(formalBaseSeed)
        expectedSeeds = formalBaseSeed + sampleIndex * 100000 + ...
            (1:expectedRepeats)';
        if ~isequal(directMeta.seeds, double(expectedSeeds))
            error('W1:FormalSeedMismatch', ...
                'Short sample %d has the wrong formal seeds.', sampleIndex);
        end
    end
end
fprintf('Validated all %d paired short-time samples.\n', numSamples);
end


function meta = inspectShortFile(path, expectedRepeats)
% Check schema and small provenance variables without loading trait cells.
if ~isfile(path)
    error('W1:MissingInput', 'Missing short simulation file: %s', path);
end
info = whos('-file', path);
names = string({info.name});
required = ["exactTraits", "binCounts", "binEdges", "seeds", ...
    "baseTraitsIndex"];
if ~all(ismember(required, names))
    error('W1:InvalidShortSchema', ...
        'A required variable is missing from %s.', path);
end
traitInfo = info(names == "exactTraits");
countInfo = info(names == "binCounts");
if numel(traitInfo) ~= 1 || ~strcmp(traitInfo.class, 'cell') || ...
        prod(double(traitInfo.size)) ~= expectedRepeats || ...
        numel(countInfo) ~= 1 || ~strcmp(countInfo.class, 'uint32')
    error('W1:InvalidShortTraits', ...
        'exactTraits has the wrong type or repeat count in %s.', path);
end

loaded = load(path, 'binEdges', 'seeds', 'baseTraitsIndex');
meta.binEdges = double(loaded.binEdges(:).');
meta.seeds = double(loaded.seeds(:));
meta.baseTraitsIndex = double(loaded.baseTraitsIndex);
numBins = numel(meta.binEdges) - 1;
if numBins < 1 || any(~isfinite(meta.binEdges)) || ...
        any(diff(meta.binEdges) <= 0) || ...
        ~isequal(double(countInfo.size), [expectedRepeats, numBins])
    error('W1:InvalidShortDimensions', ...
        'Trait grid or binCounts dimensions are invalid in %s.', path);
end
if numel(meta.seeds) ~= expectedRepeats || ...
        any(~isfinite(meta.seeds)) || any(meta.seeds ~= round(meta.seeds)) || ...
        numel(unique(meta.seeds)) ~= expectedRepeats
    error('W1:InvalidSeeds', 'Seeds are invalid or repeated in %s.', path);
end
if ~isscalar(meta.baseTraitsIndex) || ...
        ~isfinite(meta.baseTraitsIndex) || ...
        meta.baseTraitsIndex ~= round(meta.baseTraitsIndex)
    error('W1:InvalidInitialState', ...
        'baseTraitsIndex is invalid in %s.', path);
end
end


function data = validateLongDataset(directFolder, tdtlFolder, ...
        numRepeats, expectedTargetTimes, formalBaseSeed)
% Verify every long repeat and its Direct/TDTL pairing before computation.
requireFolder(directFolder, 'Direct');
requireFolder(tdtlFolder, 'TDTL');
data.directFiles = strings(numRepeats, 1);
data.tdtlFiles = strings(numRepeats, 1);
data.targetTimes = [];
referenceTDTLEdges = [];

for repeatIndex = 1:numRepeats
    data.directFiles(repeatIndex) = fullfile(directFolder, ...
        sprintf('repeat_%04d.mat', repeatIndex));
    data.tdtlFiles(repeatIndex) = fullfile(tdtlFolder, ...
        sprintf('repeat_%04d.mat', repeatIndex));
    directMeta = inspectLongFile(data.directFiles(repeatIndex), false);
    tdtlMeta = inspectLongFile(data.tdtlFiles(repeatIndex), true);

    if ~isequal(directMeta.targetTimes, tdtlMeta.targetTimes)
        error('W1:TargetTimeMismatch', ...
            'Direct and TDTL targetTimes differ for repeat %d.', repeatIndex);
    end
    if directMeta.seed ~= tdtlMeta.seed
        error('W1:SeedMismatch', ...
            'Direct and TDTL seeds differ for long repeat %d.', repeatIndex);
    end
    if isempty(data.targetTimes)
        data.targetTimes = directMeta.targetTimes;
        referenceTDTLEdges = tdtlMeta.binEdges;
    elseif ~isequal(data.targetTimes, directMeta.targetTimes)
        error('W1:TargetTimeMismatch', ...
            'Long repeats do not share one target-time grid.');
    elseif ~isequal(referenceTDTLEdges, tdtlMeta.binEdges)
        error('W1:GridMismatch', ...
            'TDTL long repeats do not share one trait grid.');
    end

    if ~isempty(formalBaseSeed) && ...
            directMeta.seed ~= formalBaseSeed + repeatIndex
        error('W1:FormalSeedMismatch', ...
            'Long repeat %d has the wrong formal seed.', repeatIndex);
    end
end
if ~isempty(expectedTargetTimes) && ...
        ~isequal(data.targetTimes, double(expectedTargetTimes(:).'))
    error('W1:FormalTargetTimeMismatch', ...
        'The long dataset does not use the formal targetTimes.');
end
fprintf('Validated all %d paired long-time repeats.\n', numRepeats);
end


function meta = inspectLongFile(path, requireBinEdges)
% Validate a long snapshot file without loading its large cell contents.
if ~isfile(path)
    error('W1:MissingInput', 'Missing long simulation file: %s', path);
end
info = whos('-file', path);
names = string({info.name});
required = ["traitSnapshots", "targetTimes", "seed"];
if requireBinEdges
    required(end + 1) = "binEdges";
end
if ~all(ismember(required, names)) || ismember("actualTimes", names)
    error('W1:InvalidLongSchema', 'Invalid long input schema: %s', path);
end
snapshotInfo = info(names == "traitSnapshots");
if numel(snapshotInfo) ~= 1 || ~strcmp(snapshotInfo.class, 'cell')
    error('W1:InvalidLongSnapshots', ...
        'traitSnapshots must be a cell array in %s.', path);
end
if requireBinEdges
    loaded = load(path, 'targetTimes', 'seed', 'binEdges');
    meta.binEdges = double(loaded.binEdges(:).');
    if numel(meta.binEdges) < 2 || any(~isfinite(meta.binEdges)) || ...
            any(diff(meta.binEdges) <= 0)
        error('W1:InvalidGrid', 'binEdges is invalid in %s.', path);
    end
else
    loaded = load(path, 'targetTimes', 'seed');
    meta.binEdges = [];
end
meta.targetTimes = double(loaded.targetTimes(:).');
meta.seed = double(loaded.seed);
if isempty(meta.targetTimes) || any(~isfinite(meta.targetTimes)) || ...
        any(diff(meta.targetTimes) <= 0) || ...
        prod(double(snapshotInfo.size)) ~= numel(meta.targetTimes)
    error('W1:InvalidLongDimensions', ...
        'targetTimes or snapshot dimensions are invalid in %s.', path);
end
if ~isscalar(meta.seed) || ~isfinite(meta.seed) || ...
        meta.seed ~= round(meta.seed)
    error('W1:InvalidSeed', 'The repeat seed is invalid in %s.', path);
end
end


function W1 = computeShortW1(data, outputFile, expectedRepeats)
% Compute every short sample after the full dataset has passed validation.
discardOldMetric(outputFile);
W1 = nan(numel(data.directFiles), 1);
for sampleIndex = 1:numel(data.directFiles)
    directTraits = loadShortTraits( ...
        data.directFiles(sampleIndex), expectedRepeats);
    tdtlTraits = loadShortTraits( ...
        data.tdtlFiles(sampleIndex), expectedRepeats);
    W1(sampleIndex) = exactMeanECDFDistance(directTraits, tdtlTraits);
    fprintf('Short W1 sample %d/%d = %.12g\n', ...
        sampleIndex, numel(data.directFiles), W1(sampleIndex));
end
saveW1(outputFile, W1);
end


function W1 = computeLongW1(data, outputFile, blockSize)
% Compute long W1 in memory-bounded time blocks after full preflight.
discardOldMetric(outputFile);
W1 = nan(numel(data.targetTimes), 1);
for firstIndex = 1:blockSize:numel(data.targetTimes)
    lastIndex = min(numel(data.targetTimes), firstIndex + blockSize - 1);
    timeIndices = firstIndex:lastIndex;
    directBlock = loadSnapshotBlock(data.directFiles, timeIndices);
    tdtlBlock = loadSnapshotBlock(data.tdtlFiles, timeIndices);
    for localIndex = 1:numel(timeIndices)
        W1(timeIndices(localIndex)) = exactMeanECDFDistance( ...
            directBlock(:, localIndex), tdtlBlock(:, localIndex));
    end
    fprintf('Long W1 completed indices %d-%d/%d.\n', ...
        firstIndex, lastIndex, numel(data.targetTimes));
end
saveW1(outputFile, W1);
end


function traits = loadShortTraits(path, expectedRepeats)
% Load continuous traits after schema validation and check their contents.
loaded = load(path, 'exactTraits');
traits = loaded.exactTraits(:);
if numel(traits) ~= expectedRepeats
    error('W1:RepeatCountChanged', ...
        'exactTraits changed after preflight in %s.', path);
end
end


function block = loadSnapshotBlock(files, timeIndices)
% Read only requested snapshot cells from each v7.3 long result.
block = cell(numel(files), numel(timeIndices));
for repeatIndex = 1:numel(files)
    info = whos('-file', files(repeatIndex), 'traitSnapshots');
    fileObject = matfile(files(repeatIndex));
    if info.size(1) == 1
        cells = fileObject.traitSnapshots(1, timeIndices);
    else
        cells = fileObject.traitSnapshots(timeIndices, 1).';
    end
    block(repeatIndex, :) = cells;
end
end


function value = exactMeanECDFDistance(traitCellsA, traitCellsB)
% Integrate the exact difference between two replicate-weighted mean ECDFs.
[traitsA, weightsA] = empiricalAtoms(traitCellsA, 1);
[traitsB, weightsB] = empiricalAtoms(traitCellsB, -1);
allTraits = [traitsA; traitsB];
allWeights = [weightsA; weightsB];
[sortedTraits, order] = sort(allTraits);
sortedWeights = allWeights(order);

newPoint = [true; diff(sortedTraits) ~= 0];
uniqueTraits = sortedTraits(newPoint);
groupIndex = cumsum(newPoint);
signedMass = accumarray(groupIndex, sortedWeights, ...
    [numel(uniqueTraits), 1]);
cdfDifference = cumsum(signedMass);
if numel(uniqueTraits) < 2
    value = 0;
else
    value = sum(abs(cdfDifference(1:end-1)) .* diff(uniqueTraits));
end
if ~isfinite(value) || value < -1e-12
    error('W1:InvalidResult', 'Computed W1 is nonfinite or negative.');
end
value = max(value, 0);
end


function [traits, weights] = empiricalAtoms(traitCells, signValue)
% Give each nonempty replicate total mass 1/R.
if ~iscell(traitCells) || isempty(traitCells)
    error('W1:InvalidCells', 'W1 inputs must be nonempty cell arrays.');
end
traitCells = traitCells(:);
for repeatIndex = 1:numel(traitCells)
    traitCells{repeatIndex} = double(traitCells{repeatIndex}(:));
    if isempty(traitCells{repeatIndex}) || ...
            any(~isfinite(traitCells{repeatIndex}))
        error('W1:EmptyOrInvalidRepeat', ...
            'Every W1 repeat must contain finite continuous traits.');
    end
end
populationSizes = cellfun(@numel, traitCells);
traits = vertcat(traitCells{:});
weightCells = cell(numel(traitCells), 1);
for repeatIndex = 1:numel(traitCells)
    weightCells{repeatIndex} = repmat( ...
        signValue ./ (numel(traitCells) .* populationSizes(repeatIndex)), ...
        populationSizes(repeatIndex), 1);
end
weights = vertcat(weightCells{:});
end


function discardOldMetric(outputFile)
% Ensure this invocation cannot silently reuse an earlier metric.
if isfile(outputFile)
    delete(outputFile);
end
partFile = string(outputFile) + ".part.mat";
if isfile(partFile)
    delete(partFile);
end
end


function saveW1(outputFile, W1)
% Save only W1 after the complete requested vector has been calculated.
partFile = string(outputFile) + ".part.mat";
save(partFile, 'W1', '-v7.3');
movefile(partFile, outputFile, 'f');
end


function requireFolder(path, methodName)
if ~isfolder(path)
    error('W1:MissingDataFolder', ...
        'Missing %s data folder: %s', methodName, path);
end
end


function codesRoot = findCodesRoot(startDirectory)
% Walk upward to locate the enclosing Codes tree.
codesRoot = startDirectory;
while true
    if isfile(fullfile(codesRoot, 'checkDependencies.m')) && ...
            isfolder(fullfile(codesRoot, 'Direct method')) && ...
            isfolder(fullfile(codesRoot, ...
            'Trait-discretized tau-leaping method'))
        return
    end
    parent = fileparts(codesRoot);
    if strcmp(parent, codesRoot)
        error('W1:CodesRootNotFound', ...
            'Could not locate the enclosing Codes directory.');
    end
    codesRoot = parent;
end
end
