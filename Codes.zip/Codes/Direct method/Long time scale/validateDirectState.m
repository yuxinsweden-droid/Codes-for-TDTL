function validateDirectState(traitBuffer, n, modelParams, ...
        birthRates, deathRates)
%VALIDATEDIRECTSTATE Check traits and optionally audit cached exact rates.
% Passing rate buffers enables a full-recomputation audit for debug/tests.
% Production runs with debugMode=false do not perform this O(n^2) check.

if n < 0 || n > numel(traitBuffer) || n ~= round(n)
    error('validateDirectState:InvalidPopulationSize', ...
        'The active population size is invalid.');
end
activeTraits = traitBuffer(1:n);
if any(~isfinite(activeTraits)) || ...
        any(activeTraits < modelParams.traitMin) || ...
        any(activeTraits > modelParams.traitMax)
    error('validateDirectState:InvalidTrait', ...
        'An active trait is nonfinite or outside the model domain.');
end
if nargin == 3
    return
end
if nargin ~= 5 || numel(birthRates) ~= numel(traitBuffer) || ...
        numel(deathRates) ~= numel(traitBuffer)
    error('validateDirectState:RateBufferSize', ...
        'Birth and death rate buffers must match the trait-buffer capacity.');
end
if any(~isfinite(birthRates)) || any(~isfinite(deathRates)) || ...
        any(birthRates < 0) || any(deathRates < 0) || ...
        any(birthRates(n + 1:end) ~= 0) || ...
        any(deathRates(n + 1:end) ~= 0)
    error('validateDirectState:InvalidCachedRate', ...
        'Rates must be finite, nonnegative and zero outside the active state.');
end
if n == 0
    return
end
[expectedBirth, expectedDeath] = computeRates(activeTraits, n, modelParams);
tolerance = 1e-11 .* max(1, max([expectedBirth, expectedDeath]));
if any(abs(birthRates(1:n) - expectedBirth) > tolerance) || ...
        any(abs(deathRates(1:n) - expectedDeath) > tolerance)
    error('validateDirectState:CachedRateMismatch', ...
        'Incremental rates disagree with complete recomputation.');
end
end

