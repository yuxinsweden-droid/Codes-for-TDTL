function [traitBuffer, n, dt, birthRates, deathRates, eventOccurred] = simulateStep( ...
        n, traitBuffer, birthRates, deathRates, ...
        modelParams, algParams, remainingTime, waitingTime)
%SIMULATESTEP Execute one exact event and incrementally update its rates.
%
% All three buffers have the same capacity; only entries 1:n are active.
% Rates must initially come from computeRates and the returned buffers must
% be passed to the next event.  Death swaps all three aligned entries.
%
% The event-selection mechanism is reusable for individual birth-death
% models.  The Gaussian mutation and trait-boundary rules near the end of
% this function belong to the present model and must be reconsidered when
% event semantics change.
%
% algParams.bufferGrowth controls only memory allocation.  When a
% birth exhausts capacity, all three buffers grow by this many slots.
% remainingTime optionally limits the waiting interval (default Inf).  An
% event beyond it is not selected or applied: dt is the remaining interval,
% all buffers are unchanged, and eventOccurred is false.  A failed mutant
% birth is still an occurred event, even though it leaves the state unchanged.
% A supplied waitingTime was already drawn by a recording driver, allowing
% observation times to be filled before the event without drawing again.

if nargin < 7
    remainingTime = Inf;
end
if ~isnumeric(remainingTime) || ~isreal(remainingTime) || ...
        ~isscalar(remainingTime) || isnan(remainingTime) || remainingTime < 0
    error('simulateStep:InvalidRemainingTime', ...
        'remainingTime must be a nonnegative real scalar, or Inf.');
end
eventOccurred = false;
if remainingTime == 0
    dt = 0;
    return
end

birthRates = reshape(double(birthRates), 1, []);
deathRates = reshape(double(deathRates), 1, []);
if n < 1 || n > numel(traitBuffer) || ...
        numel(birthRates) ~= numel(traitBuffer) || ...
        numel(deathRates) ~= numel(traitBuffer)
    error('simulateStep:InvalidState', ...
        'Trait and rate buffers must align with a nonempty active population.');
end
if ~isfield(algParams, 'bufferGrowth') || ...
        ~isscalar(algParams.bufferGrowth) || ...
        algParams.bufferGrowth < 1 || ...
        algParams.bufferGrowth ~= round(algParams.bufferGrowth)
    error('simulateStep:InvalidBufferGrowth', ...
        'algParams.bufferGrowth must be a positive integer.');
end

deathTotal = sum(deathRates(1:n));
totalRate = deathTotal + sum(birthRates(1:n));
if totalRate == 0
    dt = remainingTime;
    return
end
if ~isfinite(totalRate) || totalRate < 0
    error('simulateStep:InvalidTotalRate', ...
        'Total event propensity must be finite and positive.');
end

if nargin < 8 || isempty(waitingTime)
    dt = -log(max(rand, realmin)) ./ totalRate;
else
    if ~isnumeric(waitingTime) || ~isreal(waitingTime) || ...
            ~isscalar(waitingTime) || isnan(waitingTime) || waitingTime < 0
        error('simulateStep:InvalidWaitingTime', ...
            'A supplied waitingTime must be a nonnegative real scalar.');
    end
    dt = waitingTime;
end
if dt > remainingTime
    dt = remainingTime;
    return
end
eventOccurred = true;
draw = rand .* totalRate;
cumulative = 0;
selected = n;

if draw < deathTotal
    isDeath = true;
    for individual = 1:n
        cumulative = cumulative + deathRates(individual);
        if cumulative > draw
            selected = individual;
            break
        end
    end
else
    isDeath = false;
    draw = draw - deathTotal;
    for individual = 1:n
        cumulative = cumulative + birthRates(individual);
        if cumulative > draw
            selected = individual;
            break
        end
    end
end

parentTrait = traitBuffer(selected);
if isDeath
    % Use the old population before overwriting the deceased trait.
    [birthRates, deathRates] = updateRatesAfterEvent( ...
        traitBuffer, n, birthRates, deathRates, modelParams, ...
        true, parentTrait, selected);
    traitBuffer(selected) = traitBuffer(n);
    traitBuffer(n) = 0;
    n = n - 1;
    return
end

if rand < modelParams.mutaProb
    offspringTrait = normrnd(parentTrait, modelParams.mutaDeviation);
else
    offspringTrait = parentTrait;
end
if offspringTrait < modelParams.traitMin || ...
        offspringTrait > modelParams.traitMax
    return
end

if numel(traitBuffer) < n + 1
    traitBuffer = [traitBuffer, zeros(1, algParams.bufferGrowth)];
    birthRates = [birthRates, zeros(1, algParams.bufferGrowth)];
    deathRates = [deathRates, zeros(1, algParams.bufferGrowth)];
end
[birthRates, deathRates] = updateRatesAfterEvent( ...
    traitBuffer, n, birthRates, deathRates, modelParams, ...
    false, offspringTrait, selected);
traitBuffer(n + 1) = offspringTrait;
n = n + 1;
end
