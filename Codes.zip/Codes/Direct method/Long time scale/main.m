%% Dieckmann-Doebeli example: long-time optimized Direct method
% This script reproduces the long-time protocol used in this study.  The same
% Direct event engine is used by the short-time program; only the experiment
% driver and recorded outputs differ.

clc
clear

scriptDir = fileparts(mfilename('fullpath'));
addpath(scriptDir);

%% 1. Model-specific parameters: Dieckmann-Doebeli example
modelParams.r = 1;                       % intrinsic birth rate
modelParams.K0 = 300;                    % carrying capacity
modelParams.x0 = 0;                      % carrying capacity peak
modelParams.sigmaK = 1;                  % width of carrying capacity function
modelParams.sigmaC = 0.4;                % width of competition kernel
modelParams.traitMin = -0.5;             % minimum trait
modelParams.traitMax = 0.5;              % maximum trait
modelParams.mutaProb = 0.001;            % mutation probability per birth
modelParams.mutaDeviation = 0.05;        % mutation standard deviation

%% 2. Direct-method algorithm settings
% This is an algorithmic memory setting, not a Dieckmann model parameter.
% A full trait buffer grows by 100 slots at once instead of reallocating the
% array after every birth.
algParams.bufferGrowth = 100;            % trait-buffer slots added when full

%% 3. Study-specific long-time protocol
initialPopulation = 500;
initialTrait = -0.3;
totalTime = 10000;
recordInterval = 1;
repeatTimes = 400;

%% 4. Reproducibility and runtime settings
baseSeed = 20260618;
useParallel = true;
numWorkers = [];       % [] lets MATLAB choose the local-pool size.
debugMode = false;     % true validates every population update.

%% 5. Output path
outputDir = fullfile(scriptDir, 'Data2');

if ~isfolder(outputDir)
    mkdir(outputDir);
end

% Both long-time methods use this exact 10,001-point grid. Each snapshot is
% the state at its target: pre-event before the next event, post-event at an
% exactly coincident event. Recording retains sampled waits, so it does not
% change the exact path. Event times need not be saved.
targetTimes = 0:recordInterval:totalTime;
if targetTimes(end) ~= totalTime
    targetTimes(end + 1) = totalTime;
end
traitDistribution.type = 'point';
traitDistribution.value = initialTrait;
traitDistribution.numIndividuals = initialPopulation;
initialTraits = initPopulation(traitDistribution);

% Seeds are assigned by repeat index before parfor starts.  Serial and
% parallel executions are therefore identical for the same MATLAB release.
parallelAvailable = ~isempty(ver('parallel')) && ...
    license('test', 'Distrib_Computing_Toolbox');
runInParallel = useParallel && parallelAvailable;
if useParallel && ~parallelAvailable
    warning('DirectLong:SerialFallback', ...
        'Parallel Computing Toolbox is unavailable; using serial execution.');
end
if runInParallel
    pool = gcp('nocreate');
    if isempty(pool)
        if isempty(numWorkers)
            parpool('local');
        else
            parpool('local', numWorkers);
        end
    elseif ~isempty(numWorkers) && pool.NumWorkers ~= numWorkers
        error('DirectLong:PoolSize', ...
            'The existing pool does not match numWorkers.');
    end
end

%% Run all long-time trajectories
if runInParallel
    parfor repeatIndex = 1:repeatTimes
        seed = baseSeed + repeatIndex;
        outputFile = fullfile(outputDir, ...
            sprintf('repeat_%04d.mat', repeatIndex));
        simulateLongDirectRepeat(initialTraits, seed, totalTime, ...
            targetTimes, modelParams, algParams, outputFile, debugMode);
    end
else
    for repeatIndex = 1:repeatTimes
        seed = baseSeed + repeatIndex;
        outputFile = fullfile(outputDir, ...
            sprintf('repeat_%04d.mat', repeatIndex));
        fprintf('Direct long repeat %d/%d.\n', repeatIndex, repeatTimes);
        simulateLongDirectRepeat(initialTraits, seed, totalTime, ...
            targetTimes, modelParams, algParams, outputFile, debugMode);
    end
end
