function [birthRates, deathRates] = updateRatesAfterEvent( ...
        traitBuffer, n, birthRates, deathRates, modelParams, ...
        isDeath, eventTrait, eventIndex)
%UPDATERATESAFTEREVENT Exact Dieckmann-Doebeli rate update in O(n) work.
%
% Inputs describe the population BEFORE the event.  For a birth, buffers
% already have a spare slot and eventTrait is the accepted offspring trait.
% For a death, eventTrait is the deceased trait at eventIndex.  This function
% swaps/removes rate entries; simulateStep performs the matching trait swap.
% Failed out-of-domain births must not call this function.
%
% Existing birth rates depend only on each individual's unchanged trait.
% The symmetric Gaussian kernel lets one vector update existing death rates
% and determine the newborn's rate.  Self-competition C(y,y)=1 is retained.
% Replace this model-specific function together with computeRates when the
% model changes; its formulas assume the current fixed model parameters.

coefficient = modelParams.r ./ modelParams.K0;
contribution = coefficient .* exp( ...
    -((traitBuffer(1:n) - eventTrait) .^ 2) ./ ...
    (2 .* modelParams.sigmaC .^ 2));

if isDeath
    deathRates(1:n) = deathRates(1:n) - contribution;
    birthRates(eventIndex) = birthRates(n);
    deathRates(eventIndex) = deathRates(n);
    birthRates(n) = 0;
    deathRates(n) = 0;
else
    deathRates(1:n) = deathRates(1:n) + contribution;
    birthRates(n + 1) = modelParams.r .* exp( ...
        -((eventTrait - modelParams.x0) .^ 2) ./ ...
        (2 .* modelParams.sigmaK .^ 2));
    deathRates(n + 1) = sum(contribution) + coefficient;
end
end
