function traitSnapshots = simulateLongDirectRepeat( ...
        initialTraits, seed, totalTime, targetTimes, modelParams, algParams, ...
        outputFile, debugMode)
%SIMULATELONGDIRECTREPEAT Run and atomically save one long Direct repeat.
%
% Snapshots are the state at each target time: targets strictly before an
% event receive its pre-event state, and a target exactly at the event gets
% its updated state.  Recording neither resamples a wait nor changes the
% exact path.  No event after totalTime is applied.  actualTimes is not saved.
% algParams.bufferGrowth controls chunked allocation, not the model.

targetTimes = reshape(double(targetTimes), 1, []);
if ~isscalar(totalTime) || ~isfinite(totalTime) || totalTime < 0 || ...
        any(~isfinite(targetTimes)) || any(targetTimes < 0) || ...
        any(targetTimes > totalTime) || any(diff(targetTimes) <= 0)
    error('DirectLong:InvalidObservationTimes', ...
        'Observation times must increase within [0,totalTime].');
end

rng(seed, 'twister');
n = numel(initialTraits);
traitBuffer = zeros(1, n + algParams.bufferGrowth);
traitBuffer(1:n) = reshape(initialTraits, 1, []);
traitSnapshots = cell(1, numel(targetTimes));
recordIndex = 1;
t = 0;
birthRates = zeros(size(traitBuffer));
deathRates = zeros(size(traitBuffer));
if n > 0
    [initialBirth, initialDeath] = computeRates( ...
        traitBuffer(1:n), n, modelParams);
    birthRates(1:n) = initialBirth;
    deathRates(1:n) = initialDeath;
end

while recordIndex <= numel(targetTimes) && t >= targetTimes(recordIndex)
    traitSnapshots{recordIndex} = traitBuffer(1:n);
    recordIndex = recordIndex + 1;
end
while t < totalTime && n > 0
    totalRate = sum(deathRates(1:n)) + sum(birthRates(1:n));
    if totalRate == 0
        t = totalTime;
        break
    end
    if ~isfinite(totalRate) || totalRate <= 0
        error('simulateStep:InvalidTotalRate', ...
            'Total event propensity must be finite and positive.');
    end
    waitingTime = -log(max(rand, realmin)) ./ totalRate;
    remainingTime = totalTime - t;
    if waitingTime > remainingTime
        t = totalTime;
        break
    end
    eventTime = min(t + waitingTime, totalTime);
    % Copy only when an observation was crossed, avoiding a pre-event buffer
    % copy at every birth/death.  The event's sampled wait is retained below.
    if recordIndex <= numel(targetTimes) && ...
            targetTimes(recordIndex) < eventTime
        preEventTraits = traitBuffer(1:n);
        while recordIndex <= numel(targetTimes) && ...
                targetTimes(recordIndex) < eventTime
            traitSnapshots{recordIndex} = preEventTraits;
            recordIndex = recordIndex + 1;
        end
    end
    [traitBuffer, n, ~, birthRates, deathRates] = simulateStep( ...
        n, traitBuffer, birthRates, deathRates, modelParams, algParams, ...
        remainingTime, waitingTime);
    t = eventTime;
    if debugMode
        validateDirectState(traitBuffer, n, modelParams, ...
            birthRates, deathRates);
    end
    while recordIndex <= numel(targetTimes) && ...
            t >= targetTimes(recordIndex)
        traitSnapshots{recordIndex} = traitBuffer(1:n);
        recordIndex = recordIndex + 1;
    end
end
while recordIndex <= numel(targetTimes)
    traitSnapshots{recordIndex} = traitBuffer(1:n);
    recordIndex = recordIndex + 1;
end

partFile = outputFile + ".part.mat";
save(partFile, 'traitSnapshots', 'targetTimes', 'seed', '-v7.3');
movefile(partFile, outputFile, 'f');
end
