function traits = initPopulation(traitDistribution)
%INITPOPULATION Create a row-vector population from an explicit definition.
%
% INPUT
%   traitDistribution - struct with field type.  For type "point", provide
%                       value and numIndividuals.  For type "exist", provide
%                       the existing continuous-trait vector in trait.
% OUTPUT
%   traits - 1-by-N row vector of continuous individual traits.

switch lower(string(traitDistribution.type))
    case "point"
        traits = repmat(traitDistribution.value, 1, ...
            traitDistribution.numIndividuals);
    case "exist"
        traits = reshape(traitDistribution.trait, 1, []);
    otherwise
        error('initPopulation:UnknownType', ...
            'Unknown initial trait distribution.');
end
end

