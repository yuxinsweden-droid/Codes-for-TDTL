function [birthRates, deathRates] = computeRates( ...
        traits, n, modelParams)
%COMPUTERATES Model-specific Dieckmann-Doebeli event propensities.
%
% INPUTS
%   traits      - active continuous individual traits, exactly n entries.
%   n           - active population size.
%   modelParams - parameters of the model, not algorithm settings.
% OUTPUTS
%   birthRates  - one birth propensity per active individual.
%   deathRates  - one competition-death propensity per active individual.
%
% Replace this function when applying the Direct method to another model.
% The Direct event engine only requires aligned, finite, nonnegative vectors.

traits = reshape(double(traits), 1, []);
if numel(traits) ~= n || n < 1
    error('computeRates:StateSizeMismatch', ...
        'The active trait vector must contain exactly n individuals.');
end

birthRates = modelParams.r .* exp( ...
    -((traits - modelParams.x0) .^ 2) ./ ...
    (2 .* modelParams.sigmaK .^ 2));
competition = exp(-((traits' - traits) .^ 2) ./ ...
    (2 .* modelParams.sigmaC .^ 2));
deathRates = modelParams.r ./ modelParams.K0 .* ...
    (competition * ones(n, 1))';

if any(~isfinite([birthRates, deathRates])) || ...
        any([birthRates, deathRates] < 0)
    error('computeRates:InvalidRate', ...
        'All individual propensities must be finite and nonnegative.');
end
end

