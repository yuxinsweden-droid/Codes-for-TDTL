function [exactTraits, binCounts] = simulateDirectRepeat( ...
        initialTraits, seed, totalTime, modelParams, algParams, binEdges, ...
        debugMode)
%SIMULATEDIRECTREPEAT Study driver for one seeded short Direct realization.
%
% algParams.bufferGrowth controls only trait-buffer allocation.  The initial
% buffer reserves that many spare slots, and simulateStep uses the same chunk
% size for later expansion.  It has no effect on model propensities.

rng(seed, 'twister');
n = numel(initialTraits);
traitBuffer = zeros(1, n + algParams.bufferGrowth);
traitBuffer(1:n) = reshape(initialTraits, 1, []);
t = 0;
birthRates = zeros(size(traitBuffer));
deathRates = zeros(size(traitBuffer));
if n > 0
    [initialBirth, initialDeath] = computeRates( ...
        traitBuffer(1:n), n, modelParams);
    birthRates(1:n) = initialBirth;
    deathRates(1:n) = initialDeath;
end

while t < totalTime && n > 0
    remainingTime = totalTime - t;
    [traitBuffer, n, dt, birthRates, deathRates] = simulateStep( ...
        n, traitBuffer, birthRates, deathRates, modelParams, algParams, ...
        remainingTime);
    if dt >= remainingTime
        t = totalTime;
    else
        t = t + dt;
    end
    if debugMode
        validateDirectState(traitBuffer, n, modelParams, ...
            birthRates, deathRates);
    end
end

exactTraits = traitBuffer(1:n);
binCounts = uint32(histcounts(exactTraits, binEdges));
if sum(double(binCounts)) ~= n
    error('DirectShort:CountMismatch', ...
        'The common analysis grid did not count every terminal trait.');
end
end
